# -*- coding: utf-8 -*-
"""
db.py — AlphaBot AWS 서버 데이터베이스 (SQLite)
=====================================================
[담는 것]
  1) users              — 회원(아이디/bcrypt해시/역할/구독상태). 비번 '해시'만 저장(평문 없음).
  2) subscription_events— 구독 부여/연장/만료 이력(감사용).
  3) payment_requests   — 수동 승인 결제 신청(관리자 콘솔에서 승인).
  4) decision_log       — 서버가 내린 모든 AI 판단(관리자 'AI 가동로그' + Fable '학습 소스').
                          · 판단 당시: ticker/decision/reason/next_check_in/price/features(JSON)
                          · 사후 정답지: fwd_1h/fwd_4h (판단 뒤 실제 수익률) — 나중에 backfill.
  5) prompt_versions    — Sonnet 시스템 프롬프트의 '진화 이력'(Fable이 주 단위로 새 버전 추가).
  6) server_config      — 런타임 스위치(서버 점검 모드, 활성 프롬프트 버전 등) key/value.
  7) admin_devices      — 관리자 신뢰기기(기기 비밀값 해시) — 웹 관리자 콘솔 보호용.

[비밀번호] 여기서는 '이미 해시된 값'만 저장/조회한다. 실제 bcrypt 해싱/JWT 발급은 auth 계층(③단계)에서.
[동시성] SQLite + WAL + 짧은 타임아웃 + 쓰기 락. FastAPI(다중 요청)에서 안전하게.
[용량관리] decision_log 는 계속 쌓이므로 prune_old_logs()로 오래된 것부터 자동 삭제(하드 포화 방지).
"""
import os
import json
import time
import sqlite3
import threading
from datetime import datetime, timedelta

from settings import settings

SCHEMA_VERSION = 1
DECISION_LOG_KEEP_DAYS = int(os.environ.get("DECISION_LOG_KEEP_DAYS", "60"))   # 학습로그 보관(일)

_write_lock = threading.Lock()   # SQLite 쓰기 직렬화(WAL이라 읽기는 동시 허용)


def _con() -> sqlite3.Connection:
    c = sqlite3.connect(settings.DB_PATH, timeout=15, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=8000")
    return c


# ── 시드용 기본 Sonnet 시스템 프롬프트(v1) ─────────────────────────────
#    실제 판단 프롬프트의 뼈대. ③단계에서 파이프라인에 물릴 때 다듬고, 이후 Fable이 주 단위로 진화시킨다.
SEED_SONNET_PROMPT = """너는 규율 있는 단기 트레이더다. DeepSeek이 정리한 시장 팩트(JSON)를 보고
각 코인을 BUY/SELL/HOLD로 판단한다. 외부의 고정 손절·익절 규칙은 없다 — 진입도 청산도 오롯이 너의 판단이다.
· BUY: 우위가 분명할 때(여러 근거가 겹칠 때)만 진입한다.
· SELL: 상승 동력이 실제로 꺾였거나(고점 대비 모멘텀 소진·지지 이탈), 애초의 진입 논리가 깨졌을 때 판다.
  이익 구간이면 동력이 식는 신호에서 확정하고, 손실이라도 논리가 무너졌으면 미루지 말고 끊는다.
  단, 단발 잡음(한 봉짜리 흔들림)만으로는 팔지 마라 — '추세 확인'을 기계적으로 기다리지 말고 종합적으로 판단하라.
· HOLD: 방향이 불분명하면 관망한다.
recent_decisions(내 최근 판단과 그 이후 실제 가격변화)가 오면 반드시 참고해, '너무 늦게 팔아 바닥에서 손절'하거나
'너무 일찍 팔아 반등을 놓치는' 같은 실수를 반복하지 마라 — 이 피드백으로 스스로 타이밍을 교정한다.
출력은 코인별로 { "decision": "BUY|SELL|HOLD", "next_check_in": 초(정수), "reason": "초압축 키워드(예: MOMENTUM_FADE+SUPPORT_BREAK)" } 형태의 JSON 하나로만 답한다.
next_check_in은 변동성이 크면 짧게(예: 60~300), 관망이면 길게(예: 900) 제안한다."""


def init_db():
    """테이블 생성 + 마이그레이션 + 시드. 서버 시작 시 1회 호출(중복 호출 안전)."""
    with _write_lock:
        c = _con()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',        -- 'user' | 'admin'
            real_name TEXT DEFAULT '',
            is_subscribed INTEGER DEFAULT 0,          -- 현재 구독 여부(0/1)
            subscription_expiry TEXT,                 -- ISO 만료일(없으면 미구독)
            tier TEXT DEFAULT 'DATA_ONLY',            -- 'AUTO' | 'DATA_ONLY'
            locked INTEGER DEFAULT 0,                 -- 로그인 자체 차단
            banned INTEGER DEFAULT 0,                 -- 강제해지(재구독 제한)
            hwid TEXT DEFAULT '',
            last_seen TEXT,
            last_mode TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS subscription_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action TEXT NOT NULL,                     -- grant|extend|expire|revoke
            tier TEXT,
            days INTEGER,
            expiry_after TEXT,
            note TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS payment_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            amount INTEGER,
            tier TEXT,
            status TEXT DEFAULT 'pending',            -- pending|approved|rejected
            message TEXT DEFAULT '',
            requested_at TEXT DEFAULT CURRENT_TIMESTAMP,
            approved_at TEXT
        );

        -- 서버가 내린 모든 AI 판단 = 관리자 가동로그 + Fable 학습 소스(사후 정답지 포함)
        CREATE TABLE IF NOT EXISTS decision_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT DEFAULT CURRENT_TIMESTAMP,        -- 판단 시각(ISO)
            ts_epoch REAL,                            -- 판단 시각(epoch) — 사후 정답지 계산용
            ticker TEXT NOT NULL,
            decision TEXT NOT NULL,                   -- BUY|SELL|HOLD
            reason TEXT DEFAULT '',                   -- 초압축 키워드
            next_check_in INTEGER,                    -- Sonnet이 제안한 다음 점검 주기(초)
            price REAL,                               -- 판단 시점 현재가(사후 수익률 기준가)
            features TEXT,                            -- 판단 근거가 된 시장 스냅샷/요약(JSON) — Fable 입력
            deepseek_ms INTEGER,                      -- 1차(DeepSeek) 지연(ms) — 모니터링
            sonnet_ms INTEGER,                        -- 최종(Sonnet) 지연(ms)
            ok INTEGER DEFAULT 1,                     -- 1=정상 판단, 0=방어적 HOLD(실패대체)
            fwd_1h REAL,                              -- 사후 정답지: 판단 뒤 1시간 실제 수익률(%)
            fwd_4h REAL,                              -- 사후 정답지: 판단 뒤 4시간 실제 수익률(%)
            fwd_filled_at TEXT                        -- 정답지 채운 시각(둘 다 채워지면 세팅)
        );
        CREATE INDEX IF NOT EXISTS idx_dlog_ts ON decision_log(ts_epoch);
        CREATE INDEX IF NOT EXISTS idx_dlog_ticker ON decision_log(ticker, ts_epoch);
        CREATE INDEX IF NOT EXISTS idx_dlog_fill ON decision_log(fwd_filled_at, ts_epoch);

        -- Sonnet 시스템 프롬프트의 진화 이력(활성 1개 = 지금 쓰는 프롬프트)
        CREATE TABLE IF NOT EXISTS prompt_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version INTEGER NOT NULL,                 -- 단조 증가
            author TEXT DEFAULT 'seed',               -- seed|fable|manual
            system_prompt TEXT NOT NULL,
            summary TEXT DEFAULT '',                  -- 이번 진화에서 바뀐 요지(관리자 표시용)
            sample_count INTEGER DEFAULT 0,           -- 이 진화가 참고한 학습표본 수
            active INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS server_config (
            key TEXT PRIMARY KEY,
            value TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS admin_devices (
            device_id TEXT PRIMARY KEY,
            label TEXT DEFAULT '',
            trusted INTEGER DEFAULT 0,
            secret_hash TEXT,                         -- 기기 비밀값 해시(공개 device_id 유출 대비)
            first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
            last_try TEXT
        );
        """)

        # ── 기존 DB 호환: 없는 컬럼만 안전 추가(향후 스키마 확장 대비) ──
        def _addcol(table, col, ddl):
            cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
            if col not in cols:
                try:
                    c.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")
                except Exception:
                    pass
        # 폰 조회용: 클라이언트가 올린 '비민감 상태(JSON)'를 사용자별로 보관.
        _addcol("users", "status_json", "status_json TEXT DEFAULT ''")
        _addcol("users", "status_at", "status_at TEXT")

        # ── 시드: 기본 설정값 ──
        for k, v in (("maintenance_mode", "0"),        # '1'이면 신호 엔드포인트 점검중
                     ("active_prompt_version", ""),
                     ("schema_version", str(SCHEMA_VERSION))):
            c.execute("INSERT OR IGNORE INTO server_config (key, value) VALUES (?, ?)", (k, v))

        # ── 시드: 프롬프트 v1(없을 때만) ──
        row = c.execute("SELECT COUNT(*) AS n FROM prompt_versions").fetchone()
        if row["n"] == 0:
            c.execute("INSERT INTO prompt_versions (version, author, system_prompt, summary, active) "
                      "VALUES (1, 'seed', ?, '최초 시드 프롬프트', 1)", (SEED_SONNET_PROMPT,))
            c.execute("UPDATE server_config SET value='1' WHERE key='active_prompt_version'")

        # ── 시드: 관리자 계정(환경변수로만, 하드코딩 비번 없음) ──
        #    ADMIN_USERNAME/ADMIN_PASSWORD_HASH 가 있으면 시드. (해시는 auth.hash_password로 미리 생성)
        admin_user = (os.environ.get("ADMIN_USERNAME", "") or "").strip()
        admin_hash = (os.environ.get("ADMIN_PASSWORD_HASH", "") or "").strip()
        if admin_user and admin_hash:
            c.execute("INSERT OR IGNORE INTO users (username, password_hash, role, real_name) "
                      "VALUES (?, ?, 'admin', '관리자')", (admin_user, admin_hash))

        c.commit()
        c.close()


# ── server_config (key/value) ────────────────────────────────────────
def get_config(key: str, default: str = "") -> str:
    c = _con()
    row = c.execute("SELECT value FROM server_config WHERE key=?", (key,)).fetchone()
    c.close()
    return (row["value"] if row else default) or default


def set_config(key: str, value: str):
    with _write_lock:
        c = _con()
        c.execute("INSERT INTO server_config (key, value) VALUES (?, ?) "
                  "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
        c.commit(); c.close()


def maintenance_on() -> bool:
    return get_config("maintenance_mode", "0") == "1"


# ── 사용자/구독 ──────────────────────────────────────────────────────
def get_user_by_name(username: str):
    c = _con()
    row = c.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    c.close()
    return dict(row) if row else None


def get_user(user_id: int):
    c = _con()
    row = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    c.close()
    return dict(row) if row else None


def create_user(username: str, password_hash: str, real_name: str = "", role: str = "user") -> int:
    """password_hash 는 '이미 bcrypt로 해싱된 값'을 받는다(평문 금지). 중복이면 ValueError."""
    with _write_lock:
        c = _con()
        try:
            cur = c.execute("INSERT INTO users (username, password_hash, real_name, role) VALUES (?, ?, ?, ?)",
                            (username, password_hash, real_name, role))
            c.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            raise ValueError("이미 존재하는 아이디입니다.")
        finally:
            c.close()


def list_users(q: str = "", limit: int = 200) -> list:
    """관리자 대시보드 회원 목록/검색."""
    c = _con()
    cols = ("id,username,real_name,role,is_subscribed,subscription_expiry,tier,locked,banned")
    if q:
        rows = c.execute(f"SELECT {cols} FROM users WHERE username LIKE ? ORDER BY id DESC LIMIT ?",
                         (f"%{q}%", limit)).fetchall()
    else:
        rows = c.execute(f"SELECT {cols} FROM users ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def save_status(user_id: int, status_json: str):
    """클라이언트가 올린 '비민감 상태(JSON 문자열)'를 사용자별로 저장(폰 조회용)."""
    with _write_lock:
        c = _con()
        c.execute("UPDATE users SET status_json=?, status_at=? WHERE id=?",
                  (status_json, datetime.now().isoformat(), user_id))
        c.commit(); c.close()


def get_status(user_id: int) -> tuple:
    """(status_json, status_at) 반환."""
    c = _con()
    row = c.execute("SELECT status_json, status_at FROM users WHERE id=?", (user_id,)).fetchone()
    c.close()
    if not row:
        return "", None
    return (row["status_json"] or ""), row["status_at"]


def is_active(user: dict) -> bool:
    """구독 유효 여부: is_subscribed=1 이고 만료일이 아직 안 지남."""
    if not user or not user.get("is_subscribed"):
        return False
    exp = user.get("subscription_expiry")
    if not exp:
        return False
    try:
        return datetime.fromisoformat(exp) > datetime.now()
    except Exception:
        return False


def grant_subscription(user_id: int, tier: str, days: int, note: str = "") -> str:
    """구독 부여/연장(남은 기간 있으면 이어서). 반환: 새 만료일(ISO)."""
    with _write_lock:
        c = _con()
        row = c.execute("SELECT is_subscribed, subscription_expiry FROM users WHERE id=?", (user_id,)).fetchone()
        base = datetime.now()
        if row and row["is_subscribed"] and row["subscription_expiry"]:
            try:
                cur = datetime.fromisoformat(row["subscription_expiry"])
                if cur > base:
                    base = cur
            except Exception:
                pass
        exp = (base + timedelta(days=int(days))).isoformat()
        c.execute("UPDATE users SET is_subscribed=1, subscription_expiry=?, tier=? WHERE id=?",
                  (exp, tier, user_id))
        c.execute("INSERT INTO subscription_events (user_id, action, tier, days, expiry_after, note) "
                  "VALUES (?, 'grant', ?, ?, ?, ?)", (user_id, tier, days, exp, note))
        c.commit(); c.close()
        return exp


# ── 결제 신청(수동 승인) ─────────────────────────────────────────────
def create_payment_request(user_id: int, username: str, amount: int, tier: str, message: str = "") -> int:
    with _write_lock:
        c = _con()
        cur = c.execute("INSERT INTO payment_requests (user_id, username, amount, tier, message) "
                        "VALUES (?, ?, ?, ?, ?)", (user_id, username, amount, tier, message))
        c.commit(); rid = cur.lastrowid; c.close()
        return rid


def pending_payments() -> list:
    c = _con()
    rows = c.execute("SELECT * FROM payment_requests WHERE status='pending' ORDER BY id DESC").fetchall()
    c.close()
    return [dict(r) for r in rows]


# ── AI 판단 로그 (관리자 모니터링 + Fable 학습 소스) ───────────────────
def log_decision(ticker: str, decision: str, reason: str = "", next_check_in: int | None = None,
                 price: float | None = None, features: dict | None = None,
                 deepseek_ms: int | None = None, sonnet_ms: int | None = None, ok: bool = True) -> int:
    now = time.time()
    with _write_lock:
        c = _con()
        cur = c.execute(
            "INSERT INTO decision_log (ts, ts_epoch, ticker, decision, reason, next_check_in, price, "
            "features, deepseek_ms, sonnet_ms, ok) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (datetime.now().isoformat(), now, ticker, decision, reason, next_check_in, price,
             (json.dumps(features, ensure_ascii=False) if features is not None else None),
             deepseek_ms, sonnet_ms, 1 if ok else 0))
        c.commit(); rid = cur.lastrowid; c.close()
        return rid


def recent_decisions_for(ticker: str, within_sec: int = 6 * 3600, limit: int = 8) -> list:
    """이 코인에 대해 서버가 최근 내린 판단(휩쏘 방지용 recent_decisions 피드백 재료)."""
    cutoff = time.time() - within_sec
    c = _con()
    rows = c.execute(
        "SELECT ts_epoch, decision, price, reason FROM decision_log "
        "WHERE ticker=? AND ts_epoch>=? AND ok=1 ORDER BY ts_epoch DESC LIMIT ?",
        (ticker, cutoff, limit)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def recent_log(limit: int = 100) -> list:
    """관리자 'AI 가동로그' 모니터링용 최근 판단 목록."""
    c = _con()
    rows = c.execute("SELECT id, ts, ticker, decision, reason, next_check_in, ok, deepseek_ms, sonnet_ms "
                     "FROM decision_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


# ── 사후 정답지(forward return) 백필 — Fable 학습용 ───────────────────
def rows_awaiting_fill(horizon_sec: int, col: str) -> list:
    """판단한 지 horizon_sec 이상 지났고 해당 정답지(col: 'fwd_1h'|'fwd_4h')가 아직 빈 행들."""
    assert col in ("fwd_1h", "fwd_4h")
    cutoff = time.time() - horizon_sec
    c = _con()
    rows = c.execute(
        f"SELECT id, ticker, price, ts_epoch FROM decision_log "
        f"WHERE {col} IS NULL AND price IS NOT NULL AND price>0 AND ts_epoch<=? "
        f"ORDER BY ts_epoch ASC LIMIT 500", (cutoff,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def set_forward_return(row_id: int, col: str, ret_pct: float):
    """정답지 채우기. 1h·4h 둘 다 차면 fwd_filled_at 세팅."""
    assert col in ("fwd_1h", "fwd_4h")
    with _write_lock:
        c = _con()
        c.execute(f"UPDATE decision_log SET {col}=? WHERE id=?", (ret_pct, row_id))
        r = c.execute("SELECT fwd_1h, fwd_4h FROM decision_log WHERE id=?", (row_id,)).fetchone()
        if r and r["fwd_1h"] is not None and r["fwd_4h"] is not None:
            c.execute("UPDATE decision_log SET fwd_filled_at=? WHERE id=?",
                      (datetime.now().isoformat(), row_id))
        c.commit(); c.close()


def training_samples(since_days: int = 7, need_filled: bool = True, limit: int = 5000) -> list:
    """Fable 주간 학습용 표본: 최근 since_days 안의, (정답지가 채워진) 판단들."""
    cutoff = time.time() - since_days * 86400
    cond = "AND fwd_filled_at IS NOT NULL" if need_filled else ""
    c = _con()
    rows = c.execute(
        f"SELECT ts, ticker, decision, reason, price, features, fwd_1h, fwd_4h "
        f"FROM decision_log WHERE ts_epoch>=? {cond} ORDER BY ts_epoch DESC LIMIT ?",
        (cutoff, limit)).fetchall()
    c.close()
    out = []
    for r in rows:
        d = dict(r)
        if d.get("features"):
            try:
                d["features"] = json.loads(d["features"])
            except Exception:
                pass
        out.append(d)
    return out


def prune_old_logs(keep_days: int = DECISION_LOG_KEEP_DAYS) -> int:
    """keep_days보다 오래된 판단 로그 삭제(하드 용량 포화 방지). 반환: 삭제 건수."""
    cutoff = time.time() - keep_days * 86400
    with _write_lock:
        c = _con()
        cur = c.execute("DELETE FROM decision_log WHERE ts_epoch < ?", (cutoff,))
        c.commit(); n = cur.rowcount; c.close()
        return n


# ── 프롬프트 진화 이력 (Fable) ───────────────────────────────────────
def active_prompt() -> dict | None:
    """지금 Sonnet이 쓰는 활성 시스템 프롬프트."""
    c = _con()
    row = c.execute("SELECT * FROM prompt_versions WHERE active=1 ORDER BY version DESC LIMIT 1").fetchone()
    c.close()
    return dict(row) if row else None


def add_prompt_version(system_prompt: str, summary: str = "", author: str = "fable",
                       sample_count: int = 0, activate: bool = True) -> int:
    """새 프롬프트 버전 추가(주로 Fable). activate=True면 이걸 활성으로 전환."""
    with _write_lock:
        c = _con()
        row = c.execute("SELECT COALESCE(MAX(version),0) AS v FROM prompt_versions").fetchone()
        nextv = int(row["v"]) + 1
        if activate:
            c.execute("UPDATE prompt_versions SET active=0")
        cur = c.execute("INSERT INTO prompt_versions (version, author, system_prompt, summary, sample_count, active) "
                        "VALUES (?, ?, ?, ?, ?, ?)",
                        (nextv, author, system_prompt, summary, sample_count, 1 if activate else 0))
        if activate:
            c.execute("INSERT INTO server_config (key, value) VALUES ('active_prompt_version', ?) "
                      "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(nextv),))
        c.commit(); rid = cur.lastrowid; c.close()
        return rid


def list_prompt_versions(limit: int = 50) -> list:
    """관리자 대시보드 'Fable 진화 이력'."""
    c = _con()
    rows = c.execute("SELECT id, version, author, summary, sample_count, active, created_at "
                     "FROM prompt_versions ORDER BY version DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


# ── 관리자 대시보드 통계 ─────────────────────────────────────────────
def admin_stats() -> dict:
    c = _con()
    total = c.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
    subs = c.execute("SELECT COUNT(*) AS n FROM users WHERE is_subscribed=1 AND "
                     "subscription_expiry > ?", (datetime.now().isoformat(),)).fetchone()["n"]
    auto = c.execute("SELECT COUNT(*) AS n FROM users WHERE is_subscribed=1 AND tier='AUTO' AND "
                     "subscription_expiry > ?", (datetime.now().isoformat(),)).fetchone()["n"]
    pend = c.execute("SELECT COUNT(*) AS n FROM payment_requests WHERE status='pending'").fetchone()["n"]
    logs = c.execute("SELECT COUNT(*) AS n FROM decision_log").fetchone()["n"]
    pv = c.execute("SELECT MAX(version) AS v FROM prompt_versions").fetchone()["v"]
    banned_n = c.execute("SELECT COUNT(*) AS n FROM users WHERE banned=1").fetchone()["n"]
    soon_days = int(getattr(settings, "EXPIRE_SOON_DAYS", 3))
    soon_cut = (datetime.now() + timedelta(days=soon_days)).isoformat()
    expiring = c.execute("SELECT COUNT(*) AS n FROM users WHERE is_subscribed=1 AND "
                         "subscription_expiry > ? AND subscription_expiry <= ?",
                         (datetime.now().isoformat(), soon_cut)).fetchone()["n"]
    # 이번 달 승인된 결제 매출(원)
    month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()
    rev = c.execute("SELECT COALESCE(SUM(amount),0) AS s FROM payment_requests "
                    "WHERE status='approved' AND approved_at >= ?", (month_start,)).fetchone()["s"]
    c.close()
    return {"members": total, "active_subs": subs, "auto_subs": auto,
            "pending_payments": pend, "decision_logs": logs,
            "prompt_version": pv, "maintenance": maintenance_on(),
            "banned": banned_n, "expiring_soon": expiring, "revenue_month": rev}


# ── 관리자 액션: 차단/잠금/구독취소/삭제/비번리셋 ─────────────────────
def set_user_flag(user_id: int, field: str, value: int) -> bool:
    """banned/locked 플래그 설정(관리자). 반환: 성공 여부."""
    if field not in ("banned", "locked"):
        raise ValueError("bad field")
    with _write_lock:
        c = _con()
        cur = c.execute(f"UPDATE users SET {field}=? WHERE id=?", (1 if value else 0, user_id))
        c.commit(); ok = cur.rowcount > 0; c.close()
        return ok


def revoke_subscription(user_id: int, note: str = "") -> bool:
    """구독 즉시 취소(is_subscribed=0). 만료일은 이력용으로 남기되 무효화. 반환: 성공 여부."""
    with _write_lock:
        c = _con()
        row = c.execute("SELECT tier FROM users WHERE id=?", (user_id,)).fetchone()
        if not row:
            c.close(); return False
        c.execute("UPDATE users SET is_subscribed=0 WHERE id=?", (user_id,))
        c.execute("INSERT INTO subscription_events (user_id, action, tier, days, expiry_after, note) "
                  "VALUES (?, 'revoke', ?, 0, NULL, ?)", (user_id, row["tier"], note))
        c.commit(); c.close()
        return True


def delete_user(user_id: int) -> bool:
    """회원 완전 삭제 + 관련 이력(구독/결제) 정리. 관리자 계정/자기자신 보호는 라우트에서."""
    with _write_lock:
        c = _con()
        exists = c.execute("SELECT 1 FROM users WHERE id=?", (user_id,)).fetchone()
        if not exists:
            c.close(); return False
        c.execute("DELETE FROM subscription_events WHERE user_id=?", (user_id,))
        c.execute("DELETE FROM payment_requests WHERE user_id=?", (user_id,))
        c.execute("DELETE FROM users WHERE id=?", (user_id,))
        c.commit(); c.close()
        return True


def set_password(user_id: int, password_hash: str) -> bool:
    """관리자 비밀번호 리셋(이미 해싱된 값). 반환: 성공 여부."""
    with _write_lock:
        c = _con()
        cur = c.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash, user_id))
        c.commit(); ok = cur.rowcount > 0; c.close()
        return ok


def get_user_detail(user_id: int) -> dict | None:
    """회원 1명 상세: 프로필 + 최근 구독이력 + 결제이력."""
    c = _con()
    u = c.execute("SELECT id,username,real_name,role,is_subscribed,subscription_expiry,tier,"
                  "locked,banned,last_seen,last_mode,created_at,status_at FROM users WHERE id=?",
                  (user_id,)).fetchone()
    if not u:
        c.close(); return None
    subs = c.execute("SELECT action,tier,days,expiry_after,note,created_at FROM subscription_events "
                     "WHERE user_id=? ORDER BY id DESC LIMIT 20", (user_id,)).fetchall()
    pays = c.execute("SELECT id,amount,tier,status,requested_at,approved_at FROM payment_requests "
                     "WHERE user_id=? ORDER BY id DESC LIMIT 20", (user_id,)).fetchall()
    c.close()
    d = dict(u)
    d["subscription_events"] = [dict(r) for r in subs]
    d["payments"] = [dict(r) for r in pays]
    return d


# ── 결제 내역(전체) / 거절 ───────────────────────────────────────────
def payment_history(limit: int = 100) -> list:
    """대기/승인/거절 전부 포함한 결제 신청 내역."""
    c = _con()
    rows = c.execute("SELECT id, user_id, username, amount, tier, status, requested_at, approved_at "
                     "FROM payment_requests ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def reject_payment(rid: int) -> bool:
    """대기중 결제신청을 거절 처리. 반환: 성공 여부."""
    with _write_lock:
        c = _con()
        cur = c.execute("UPDATE payment_requests SET status='rejected', approved_at=? "
                        "WHERE id=? AND status='pending'", (datetime.now().isoformat(), rid))
        c.commit(); ok = cur.rowcount > 0; c.close()
        return ok


# ── 만료 임박(알림/대시보드) ─────────────────────────────────────────
def expiring_soon(days: int = 3) -> list:
    """앞으로 days일 이내에 만료되는 활성 구독자."""
    now = datetime.now().isoformat()
    cut = (datetime.now() + timedelta(days=int(days))).isoformat()
    c = _con()
    rows = c.execute("SELECT id, username, tier, subscription_expiry FROM users "
                     "WHERE is_subscribed=1 AND subscription_expiry > ? AND subscription_expiry <= ? "
                     "ORDER BY subscription_expiry ASC", (now, cut)).fetchall()
    c.close()
    return [dict(r) for r in rows]
