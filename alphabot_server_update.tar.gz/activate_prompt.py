# -*- coding: utf-8 -*-
"""
activate_prompt.py — '순수 AI 판단' 프롬프트를 활성 버전으로 1회 전환.
=====================================================
기존에 돌던 서버의 활성 프롬프트(규칙 손절/익절 강제 버전)를, DeepSeek+Sonnet의
재량을 넓힌 새 프롬프트로 교체한다. 서버는 매 분석마다 활성 프롬프트를 새로 읽으므로
'재시작 없이 즉시' 적용된다. 이후 일요일마다 Fable이 이 프롬프트를 진화시킨다.

실행(서버 앱 폴더에서, DB_PATH가 .env에 있으면 함께 로드):
    set -a; source .env 2>/dev/null; set +a; python3 activate_prompt.py
"""
import db

NEW_PROMPT = """너는 규율 있는 단기 트레이더다. DeepSeek이 정리한 시장 팩트(JSON)를 보고
각 코인을 BUY/SELL/HOLD로 판단한다. 외부의 고정 손절·익절 규칙은 없다 — 진입도 청산도 오롯이 너의 판단이다.
· BUY: 우위가 분명할 때(여러 근거가 겹칠 때)만 진입한다.
· SELL: 상승 동력이 실제로 꺾였거나(고점 대비 모멘텀 소진·지지 이탈), 애초의 진입 논리가 깨졌을 때 판다.
  이익 구간이면 동력이 식는 신호에서 확정하고, 손실이라도 논리가 무너졌으면 미루지 말고 끊는다.
  단, 단발 잡음(한 봉짜리 흔들림)만으로는 팔지 마라 — '추세 확인'을 기계적으로 기다리지 말고 종합적으로 판단하라.
· HOLD: 방향이 불분명하면 관망한다.
recent_decisions(내 최근 판단과 그 이후 실제 가격변화)가 오면 반드시 참고해, '너무 늦게 팔아 바닥에서 손절'하거나
'너무 일찍 팔아 반등을 놓치는' 같은 실수를 반복하지 마라 — 이 피드백으로 스스로 타이밍을 교정한다.
출력은 코인별로 { "decision": "BUY|SELL|HOLD", "next_check_in": 초(정수), "reason": "초압축 키워드(예: MOMENTUM_FADE+SUPPORT_BREAK)" } 형태의 JSON 하나로만 답한다.
next_check_in은 변동성이 크면 짧게(예: 60~300), 관망이면 길게(예: 900) 제안한다."""


def main():
    db.init_db()   # 테이블 보장(멱등)
    before = db.active_prompt()
    rid = db.add_prompt_version(
        NEW_PROMPT,
        summary="순수 AI 판단 전환: 규칙 손절/익절 제거, SELL 재량 확대(바닥손절 방지)",
        author="manual", sample_count=0, activate=True)
    after = db.active_prompt()
    print("──────────────────────────────────────────────")
    print(f"이전 활성: v{(before or {}).get('version','-')} ({(before or {}).get('author','-')})")
    print(f"새 활성  : v{after['version']} ({after['author']})  ← 지금부터 이걸로 판단")
    print("서버 재시작 불필요 — 다음 분석부터 즉시 적용됩니다.")
    print("이후 매주 일요일 Fable이 실제 성과 데이터로 이 프롬프트를 진화시킵니다.")
    print("──────────────────────────────────────────────")


if __name__ == "__main__":
    main()
