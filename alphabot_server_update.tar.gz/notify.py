# -*- coding: utf-8 -*-
"""
notify.py — 관리자 텔레그램 운영 알림
=====================================================
[역할] 서버에서 '운영 이벤트'(신규가입/결제신청/구독변경/만료임박)를 관리자 폰으로 push.
[성질]
  · 선택 기능 — settings.ADMIN_TG_TOKEN/ADMIN_TG_CHAT 가 비어 있으면 '조용히' 아무 것도 안 함.
  · 절대 요청을 막지 않음 — 전송은 백그라운드 스레드에서, 실패해도 서버/매매엔 영향 0.
  · 외부 의존성 없음(표준 urllib). 사용자 업비트 키/주문과 무관(민감정보 안 담음).
"""
import json
import threading
import urllib.request
import urllib.error

from settings import settings

_TG_API = "https://api.telegram.org/bot{token}/sendMessage"


def _send_sync(token: str, chat_id: str, text: str) -> None:
    body = json.dumps({"chat_id": chat_id, "text": text,
                       "parse_mode": "HTML", "disable_web_page_preview": True}).encode("utf-8")
    req = urllib.request.Request(_TG_API.format(token=token), data=body,
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(req, timeout=6).read()
    except Exception:
        # 알림 실패는 무시(로그만 남기고 싶으면 여기서 print). 서버 동작엔 영향 없음.
        pass


def notify_admin(text: str) -> None:
    """관리자에게 텔레그램 알림(비동기·안전). 토큰/chat 없으면 조용히 무시."""
    token = settings.ADMIN_TG_TOKEN
    chat = settings.ADMIN_TG_CHAT
    if not (token and chat and text):
        return
    threading.Thread(target=_send_sync, args=(token, chat, text), daemon=True).start()


# ── 이벤트별 헬퍼(문구 통일) ─────────────────────────────────────────
def on_signup(username: str, real_name: str = "") -> None:
    if not settings.NOTIFY_SIGNUP:
        return
    nm = f" ({real_name})" if real_name else ""
    notify_admin(f"🆕 <b>신규 가입</b>\n아이디: <code>{username}</code>{nm}")


def on_payment_request(username: str, tier: str, amount: int, rid: int) -> None:
    if not settings.NOTIFY_PAYMENT:
        return
    notify_admin(f"💳 <b>결제 신청</b> (승인 대기)\n"
                 f"아이디: <code>{username}</code>\n등급: {tier}\n금액: {amount:,}원\n"
                 f"신청번호: #{rid}\n→ /admin 에서 승인하세요.")


def on_subscription(username: str, tier: str, action: str, expiry: str = "") -> None:
    """action: grant|approve|extend|revoke|cancel"""
    if not settings.NOTIFY_SUB:
        return
    label = {"grant": "구독 부여", "approve": "결제 승인", "extend": "구독 연장",
             "revoke": "구독 취소", "cancel": "구독 취소"}.get(action, action)
    exp = f"\n만료: {str(expiry)[:10]}" if expiry else ""
    icon = "🚫" if action in ("revoke", "cancel") else "✅"
    notify_admin(f"{icon} <b>{label}</b>\n아이디: <code>{username}</code>\n등급: {tier}{exp}")


def on_expiring(rows: list, days: int) -> None:
    """만료 임박 사용자 요약(하루 1회). rows: [{username,tier,subscription_expiry}, ...]"""
    if not (settings.NOTIFY_EXPIRE and rows):
        return
    lines = [f"⏰ <b>구독 만료 임박</b> ({days}일 이내 {len(rows)}명)"]
    for r in rows[:20]:
        lines.append(f"· <code>{r.get('username')}</code> {r.get('tier','')} "
                     f"~ {str(r.get('subscription_expiry',''))[:10]}")
    if len(rows) > 20:
        lines.append(f"…외 {len(rows) - 20}명")
    notify_admin("\n".join(lines))
