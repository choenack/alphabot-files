# -*- coding: utf-8 -*-
"""
main.py — AlphaBot AWS 서버 (FastAPI) · 전체 통합
=====================================================
[역할 분리] 이 서버는 '공개데이터 + AI 분석 + 회원/구독'만. 사용자 업비트 키/주문은 클라이언트(PC)만.
[클라이언트 호환] /auth/login·/subscription·/signals 의 JSON/에러 형식을 기존 클라이언트가 파싱하던
                 규격에 '그대로' 맞춘다 → 클라이언트는 서버 주소만 바꾸면 됨(최소 수정).

엔드포인트
  공개데이터(디버그/검증): GET /health /v1/markets /v1/prices /v1/marketdata
  인증:               POST /auth/register  POST /auth/login  GET /subscription
  신호(구독 게이팅):    GET /signals?coins=KRW-BTC,KRW-ETH
  결제신청:            POST /payments/request
  관리자(웹 대시보드):  GET /admin/stats /admin/logs /admin/prompts /admin/payments/pending
                      POST /admin/maintenance /admin/payments/approve /admin/evolve
실행: uvicorn main:app --host 0.0.0.0 --port 8000
"""
import re
import time
from datetime import datetime
from contextlib import asynccontextmanager

from fastapi import FastAPI, Query, Header, Request, Depends, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse

import db
import auth
import market_data
import ai_pipeline
import fable
import notify
from admin_ui import ADMIN_HTML
from mobile_ui import MOBILE_HTML
from settings import settings

STATUS_PUSH_MAX = 1_200_000   # 폰 조회용 상태 JSON 최대 크기(바이트)

_TICKER_RE = re.compile(r"^KRW-[A-Z0-9]{2,10}$")
_MAX_COINS = settings.SIGNAL_MAX_COINS   # [비용 레버 4] 분석 코인 수 상한(설정 가능)


def _parse_coins(coins: str) -> list:
    raw = [c.strip().upper() for c in (coins or "").split(",") if c.strip()]
    valid = [c for c in dict.fromkeys(raw) if _TICKER_RE.match(c)]
    return valid[:_MAX_COINS]


def _sub_payload(u: dict) -> dict:
    return {"active": db.is_active(u), "tier": u.get("tier"),
            "expiry": u.get("subscription_expiry"), "username": u.get("username"),
            "banned": bool(u.get("banned"))}


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()              # 테이블 생성 + 시드
    fable.start_scheduler()   # 사후정답지 백필 + 일요일 자가진화 + 로그정리(백그라운드)
    yield


app = FastAPI(title="AlphaBot AWS Server", version="1.0.0", lifespan=lifespan)


# ── 공개데이터(검증/디버그) ──────────────────────────────────────────
@app.get("/health")
def health():
    cfg = settings.masked()
    # 텔레그램은 .env 뿐 아니라 대시보드(DB) 입력값도 반영해야 '설정 탭' 표시가 맞다.
    cfg["admin_telegram_set"] = notify.configured()
    return {"ok": True, "ts": int(time.time()), "config": cfg,
            "maintenance": db.maintenance_on()}


@app.get("/v1/markets")
def markets():
    return {"markets": market_data.get_markets_krw()}


@app.get("/v1/prices")
def prices(coins: str = Query(...)):
    ms = _parse_coins(coins)
    if not ms:
        raise HTTPException(400, "유효한 KRW 티커 없음")
    return {"prices": market_data.get_prices(ms)}


@app.get("/v1/marketdata")
def marketdata(coins: str = Query(...)):
    ms = _parse_coins(coins)
    if not ms:
        raise HTTPException(400, "유효한 KRW 티커 없음")
    t0 = time.time()
    data = market_data.collect(ms)
    data["elapsed_ms"] = int((time.time() - t0) * 1000)
    return data


# ── 인증(클라이언트 호환 형식) ───────────────────────────────────────
@app.post("/auth/register")
async def register(request: Request):
    d = await request.json()
    uid = (d.get("username") or "").strip()
    pw = d.get("password") or ""
    nm = (d.get("real_name") or "").strip()
    if len(uid) < 3 or len(pw) < 6 or not nm:
        return JSONResponse({"error": "invalid"}, status_code=400)
    try:
        db.create_user(uid, auth.hash_password(pw), nm, "user")
    except ValueError:
        return JSONResponse({"error": "duplicate"}, status_code=409)
    notify.on_signup(uid, nm)   # 관리자 텔레그램 알림(선택)
    return JSONResponse({"ok": True}, status_code=201)


@app.post("/auth/login")
async def login(request: Request):
    d = await request.json()
    uid = (d.get("username") or "").strip()
    pw = d.get("password") or ""
    user = db.get_user_by_name(uid)
    if not user or not auth.verify_password(pw, user["password_hash"]):
        return JSONResponse({"error": "bad_pw"}, status_code=401)
    if user.get("locked"):
        return JSONResponse({"error": "locked"}, status_code=403)
    # 최근 접속 기록(비필수)
    try:
        db.set_config(f"_lastseen_{user['id']}", str(int(time.time())))
    except Exception:
        pass
    token = auth.make_token(user)
    return {"token": token, "username": user["username"], "role": user.get("role", "user"),
            "subscription": _sub_payload(user)}


@app.get("/subscription")
def subscription(user: dict = Depends(auth.current_user)):
    return _sub_payload(user)


# ── 폰 조회용 상태 (클라이언트가 올리고, 폰이 본다) ──────────────────
@app.post("/status/push")
async def status_push(request: Request, user: dict = Depends(auth.current_user)):
    """클라이언트(PC)가 자기 '비민감 상태'(자산·포지션·신호 등)를 올린다. 키/주문 없음."""
    body = (await request.body()).decode("utf-8", "ignore") or "{}"
    if len(body) > STATUS_PUSH_MAX:
        return JSONResponse({"error": "too_large"}, status_code=413)
    db.save_status(user["id"], body)
    return {"ok": True}


@app.get("/status/me")
def status_me(user: dict = Depends(auth.current_user)):
    """폰 대시보드가 읽는 내 최신 상태. running 여부는 서버가 신선도로 판정."""
    import json as _json
    raw, at = db.get_status(user["id"])
    try:
        data = _json.loads(raw) if raw else {}
    except Exception:
        data = {}
    age = None
    if at:
        try:
            age = (datetime.now() - datetime.fromisoformat(at)).total_seconds()
        except Exception:
            age = None
    running = bool(data.get("running")) and (age is not None and age < 180)
    return {"username": user["username"], "status": data,
            "age_sec": (int(age) if age is not None else None),
            "running": running, "subscription": _sub_payload(user)}


@app.get("/m", response_class=HTMLResponse)
def mobile_page():
    """폰 조회용 모바일 웹 대시보드."""
    return MOBILE_HTML


# ── 신호(구독 게이팅 · 클라이언트 호환 에러코드) ─────────────────────
@app.get("/signals")
def signals(coins: str = Query(""),
            authorization: str | None = Header(default=None),
            x_bot_mode: str | None = Header(default=None),
            x_hwid: str | None = Header(default=None)):
    # 점검 모드면 '서버 일시중지'로(클라는 ServerError로 처리 → 로컬 손절감시는 계속)
    if db.maintenance_on():
        return JSONResponse({"error": "maintenance", "signals": []}, status_code=503)
    payload = auth.decode_token(authorization[7:].strip()) if (authorization or "").startswith("Bearer ") else None
    if not payload:
        return JSONResponse({"error": "unauth"}, status_code=401)
    user = db.get_user(int(payload.get("sub", 0)))
    if not user:
        return JSONResponse({"error": "unauth"}, status_code=401)
    if user.get("locked"):
        return JSONResponse({"error": "locked"}, status_code=403)
    if user.get("banned"):
        return JSONResponse({"error": "banned"}, status_code=403)
    if not db.is_active(user):
        return JSONResponse({"error": "no_subscription"}, status_code=403)
    ms = _parse_coins(coins)
    if not ms:
        return {"signals": []}
    try:
        sigs = ai_pipeline.get_signals(ms)
    except Exception as e:
        return JSONResponse({"error": f"ai_failed: {e}", "signals": []}, status_code=200)
    return {"signals": sigs}


# ── 결제 신청(수동 승인) ─────────────────────────────────────────────
@app.post("/payments/request")
async def payment_request(request: Request, user: dict = Depends(auth.current_user)):
    if user.get("banned"):
        return JSONResponse({"error": "banned"}, status_code=403)
    d = await request.json()
    tier = d.get("tier") if d.get("tier") in settings.TIERS else "DATA_ONLY"
    amount = settings.TIERS[tier]
    rid = db.create_payment_request(user["id"], user["username"], amount, tier, f"{tier} 구독 신청")
    notify.on_payment_request(user["username"], tier, amount, rid)   # 관리자 알림(제일 유용)
    return {"request_id": rid, "amount": amount, "tier": tier, "status": "pending"}


# ── 관리자(웹 대시보드) ──────────────────────────────────────────────
@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    """클릭으로 관리하는 웹 대시보드(브라우저에서 /admin 접속). 데이터는 아래 /admin/* API로."""
    return ADMIN_HTML


@app.get("/admin/stats")
def admin_stats(admin: dict = Depends(auth.admin_required)):
    return db.admin_stats()


@app.get("/admin/users")
def admin_users(q: str = "", admin: dict = Depends(auth.admin_required)):
    return {"users": db.list_users(q)}


@app.post("/admin/subscribe")
async def admin_subscribe(request: Request, admin: dict = Depends(auth.admin_required)):
    """아이디로 구독 부여/연장(대시보드 '구독 부여' 버튼)."""
    d = await request.json()
    uname = (d.get("username") or "").strip()
    tier = d.get("tier") if d.get("tier") in settings.TIERS else "DATA_ONLY"
    days = int(d.get("days", 30))
    u = db.get_user_by_name(uname)
    if not u:
        raise HTTPException(404, "그런 아이디 없음")
    exp = db.grant_subscription(u["id"], tier, days, note="관리자 대시보드 부여")
    notify.on_subscription(uname, tier, "grant", exp)
    return {"ok": True, "username": uname, "tier": tier, "expiry": exp}


@app.get("/admin/logs")
def admin_logs(limit: int = 100, admin: dict = Depends(auth.admin_required)):
    return {"logs": db.recent_log(min(max(limit, 1), 500))}


@app.get("/admin/prompts")
def admin_prompts(admin: dict = Depends(auth.admin_required)):
    return {"versions": db.list_prompt_versions(),
            "last_evolution": db.get_config("fable_last_result", "")}


@app.get("/admin/payments/pending")
def admin_pending(admin: dict = Depends(auth.admin_required)):
    return {"pending": db.pending_payments()}


@app.post("/admin/maintenance")
async def admin_maintenance(request: Request, admin: dict = Depends(auth.admin_required)):
    d = await request.json()
    db.set_config("maintenance_mode", "1" if d.get("on") else "0")
    return {"maintenance": db.maintenance_on()}


@app.post("/admin/payments/approve")
async def admin_approve(request: Request, admin: dict = Depends(auth.admin_required)):
    d = await request.json()
    rid = int(d.get("request_id", 0))
    days = int(d.get("days", 30))
    pend = {p["id"]: p for p in db.pending_payments()}
    p = pend.get(rid)
    if not p:
        raise HTTPException(404, "대기중 결제신청 아님")
    exp = db.grant_subscription(p["user_id"], p["tier"], days, note=f"결제#{rid} 승인")
    # 신청 상태 갱신
    c = db._con()
    with db._write_lock:
        c.execute("UPDATE payment_requests SET status='approved', approved_at=? WHERE id=?",
                  (time.strftime("%Y-%m-%dT%H:%M:%S"), rid))
        c.commit()
    c.close()
    notify.on_subscription(p.get("username", ""), p["tier"], "approve", exp)
    return {"ok": True, "expiry": exp, "tier": p["tier"]}


# ── 관리자: 회원 액션(강제해지/잠금/구독취소/삭제/비번리셋/상세) ─────────
def _find_user_or_404(d: dict) -> dict:
    """요청 body의 username 또는 user_id 로 회원을 찾는다."""
    uid = d.get("user_id")
    u = db.get_user(int(uid)) if uid else db.get_user_by_name((d.get("username") or "").strip())
    if not u:
        raise HTTPException(404, "그런 회원 없음")
    return u


@app.post("/admin/user/ban")
async def admin_ban(request: Request, admin: dict = Depends(auth.admin_required)):
    """강제해지(banned) 설정/해제. {username 또는 user_id, on: true/false}"""
    d = await request.json()
    u = _find_user_or_404(d)
    if u.get("role") == "admin":
        raise HTTPException(400, "관리자 계정은 차단할 수 없습니다")
    on = bool(d.get("on", True))
    db.set_user_flag(u["id"], "banned", 1 if on else 0)
    if on:
        db.revoke_subscription(u["id"], note="강제해지")
        notify.on_subscription(u["username"], u.get("tier", ""), "revoke")
    return {"ok": True, "username": u["username"], "banned": on}


@app.post("/admin/user/lock")
async def admin_lock(request: Request, admin: dict = Depends(auth.admin_required)):
    """계정잠금(locked) 설정/해제 — 로그인 자체 차단. {username 또는 user_id, on}"""
    d = await request.json()
    u = _find_user_or_404(d)
    if u.get("role") == "admin":
        raise HTTPException(400, "관리자 계정은 잠글 수 없습니다")
    on = bool(d.get("on", True))
    db.set_user_flag(u["id"], "locked", 1 if on else 0)
    return {"ok": True, "username": u["username"], "locked": on}


@app.post("/admin/subscription/cancel")
async def admin_cancel_sub(request: Request, admin: dict = Depends(auth.admin_required)):
    """구독 즉시 취소(차단은 아님). {username 또는 user_id}"""
    d = await request.json()
    u = _find_user_or_404(d)
    db.revoke_subscription(u["id"], note="관리자 구독취소")
    notify.on_subscription(u["username"], u.get("tier", ""), "cancel")
    return {"ok": True, "username": u["username"]}


@app.post("/admin/user/delete")
async def admin_delete_user(request: Request, admin: dict = Depends(auth.admin_required)):
    """회원 완전 삭제. {username 또는 user_id} — 관리자/본인은 불가."""
    d = await request.json()
    u = _find_user_or_404(d)
    if u.get("role") == "admin":
        raise HTTPException(400, "관리자 계정은 삭제할 수 없습니다")
    if u["id"] == admin["id"]:
        raise HTTPException(400, "자기 자신은 삭제할 수 없습니다")
    db.delete_user(u["id"])
    return {"ok": True, "deleted": u["username"]}


@app.post("/admin/user/reset_password")
async def admin_reset_pw(request: Request, admin: dict = Depends(auth.admin_required)):
    """회원 비밀번호 리셋. {username 또는 user_id, new_password}"""
    d = await request.json()
    u = _find_user_or_404(d)
    pw = d.get("new_password") or ""
    if len(pw) < 6:
        raise HTTPException(400, "새 비밀번호는 6자 이상")
    db.set_password(u["id"], auth.hash_password(pw))
    return {"ok": True, "username": u["username"]}


@app.get("/admin/user")
def admin_user_detail(username: str = "", id: int = 0, admin: dict = Depends(auth.admin_required)):
    """회원 1명 상세(구독/결제 이력 포함). ?username= 또는 ?id="""
    uid = id or (db.get_user_by_name(username.strip()) or {}).get("id")
    if not uid:
        raise HTTPException(404, "그런 회원 없음")
    detail = db.get_user_detail(int(uid))
    if not detail:
        raise HTTPException(404, "그런 회원 없음")
    detail["active"] = db.is_active(detail)
    return detail


@app.get("/admin/payments/history")
def admin_payments_history(limit: int = 100, admin: dict = Depends(auth.admin_required)):
    return {"history": db.payment_history(min(max(limit, 1), 500))}


@app.post("/admin/payments/reject")
async def admin_reject_payment(request: Request, admin: dict = Depends(auth.admin_required)):
    d = await request.json()
    rid = int(d.get("request_id", 0))
    ok = db.reject_payment(rid)
    if not ok:
        raise HTTPException(404, "대기중 결제신청 아님")
    return {"ok": True, "rejected": rid}


@app.get("/admin/expiring")
def admin_expiring(days: int = 0, admin: dict = Depends(auth.admin_required)):
    d = days or settings.EXPIRE_SOON_DAYS
    return {"days": d, "expiring": db.expiring_soon(d)}


# ── 관리자: 텔레그램 알림 설정(대시보드에서 직접 입력) ────────────────
@app.get("/admin/telegram")
def admin_tg_get(admin: dict = Depends(auth.admin_required)):
    """현재 연동 상태(토큰 값은 노출하지 않음). chat_id는 확인용으로 표시."""
    db_tok = db.get_config("tg_token", "")
    db_chat = db.get_config("tg_chat", "")
    env_on = bool(settings.ADMIN_TG_TOKEN and settings.ADMIN_TG_CHAT)
    source = "db" if (db_tok and db_chat) else ("env" if env_on else "none")
    return {"configured": notify.configured(), "token_set": bool(db_tok or settings.ADMIN_TG_TOKEN),
            "chat": db_chat or settings.ADMIN_TG_CHAT, "source": source}


@app.post("/admin/telegram")
async def admin_tg_set(request: Request, admin: dict = Depends(auth.admin_required)):
    """토큰/chat_id 저장. 빈 토큰은 '변경 안 함'(마스킹돼 있으니). chat은 보낸 값으로 갱신."""
    d = await request.json()
    tok = (d.get("token") or "").strip()
    chat = (d.get("chat") or "").strip()
    if tok:
        db.set_config("tg_token", tok)
    if "chat" in d:
        db.set_config("tg_chat", chat)
    return {"ok": True, "configured": notify.configured()}


@app.post("/admin/telegram/clear")
def admin_tg_clear(admin: dict = Depends(auth.admin_required)):
    """대시보드 저장값 삭제(.env 값이 있으면 그쪽으로 폴백)."""
    db.set_config("tg_token", "")
    db.set_config("tg_chat", "")
    return {"ok": True, "configured": notify.configured()}


@app.post("/admin/telegram/test")
def admin_tg_test(admin: dict = Depends(auth.admin_required)):
    """현재 설정으로 테스트 메시지 1건 발송."""
    ok, err = notify.send_test()
    return {"ok": ok, "error": err}


@app.post("/admin/evolve")
def admin_evolve(admin: dict = Depends(auth.admin_required)):
    """수동으로 Fable 자가진화 1회 실행(테스트/즉시적용용)."""
    return fable.run_weekly_evolution(force=True)
