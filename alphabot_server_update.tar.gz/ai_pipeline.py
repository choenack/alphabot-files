# -*- coding: utf-8 -*-
"""
ai_pipeline.py — 비용최적화 AI 파이프라인
=====================================================
흐름(비용 낮은 순으로 걸러냄):
  0) market_data.collect()      — 업비트 공개데이터(무료) 수집
  1) 규칙 사전필터(무료)         — 명백히 지루한(중립) 코인은 LLM 없이 즉시 HOLD  [레버5]
  2) 1차 판단(값싼 base=DeepSeek)— 관심 코인만. decision + confidence 출력       [레버3]
  3) Sonnet 재확인              — BUY/SELL 또는 '확신 없는 HOLD'만 (놓친 기회 잡기) [확신도 에스컬레이션]
     · '확신있는 HOLD'만 싸게 통과. BUY/SELL·애매한 HOLD는 Sonnet이 최종 판단.
공유 캐시 + in-flight 로 여러 사용자가 같은 코인을 요청해도 '한 번만' 분석해 공유.
Claude 호출엔 prompt caching 적용(반복 시스템프롬프트 입력비용 절감) [레버2].
"""
import re
import json
import time
import threading

import requests

import db
import market_data
from settings import settings

# ── 공유 캐시 + in-flight ────────────────────────────────────────────
_cache = {}      # ticker -> (expire_epoch, signal_dict)
_inflight = {}   # ticker -> threading.Event
_fail_streak = {}
_lock = threading.Lock()
INFLIGHT_WAIT = 100


# ── 허용 reason 키워드(짧게!) → 한국어 ───────────────────────────────
#   [비용] reason은 출력토큰이라 길면 돈이 든다. AI가 이 목록에서 '최대 3개'만 쓰게 강제한다.
KEYWORD_KO = {
    "RSI_LOW": "과매도", "RSI_HIGH": "과매수", "RSI_NEUTRAL": "RSI중립", "RSI_UP": "RSI반등", "RSI_DOWN": "RSI하락",
    "MACD_UP": "MACD상승", "MACD_DOWN": "MACD하락", "MACD_FADE": "MACD약화",
    "BB_LOW": "볼밴하단", "BB_UP": "볼밴상단",
    "VOL_UP": "거래량급증", "VOL_DOWN": "거래량위축",
    "PULLBACK": "눌림목", "REBOUND": "반등", "BREAKOUT": "돌파", "SIDEWAYS": "횡보",
    "SUPPORT": "지지", "RESISTANCE": "저항",
    "OB_BID": "매수벽우위", "OB_ASK": "매도벽우위",
    "BTC_WEAK": "BTC약세", "BTC_STRONG": "BTC강세",
    "WHIPSAW": "휩쏘우려", "MIXED": "신호혼재", "NO_SETUP": "셋업없음",
    "CALM_NO_SETUP": "관망(셋업없음)", "LOW_CONFIDENCE": "근거부족",
}
# AI에게 제시할 허용 목록(사후필터에도 사용)
REASON_VOCAB = [k for k in KEYWORD_KO if k not in ("CALM_NO_SETUP", "LOW_CONFIDENCE")]
_VOCAB_SET = set(REASON_VOCAB)


def _sanitize_reason(code: str) -> str:
    """AI가 목록 밖 단어를 써도 서버에서 잘라 최대 3개 허용키워드만 남긴다(출력 낭비 방어)."""
    if not code:
        return "MIXED"
    toks = [t.strip().upper() for t in re.split(r"[+,/ ]+", code) if t.strip()]
    kept = [t for t in toks if t in _VOCAB_SET][:3]
    return "+".join(kept) if kept else "MIXED"


def _reason_ko(code: str) -> str:
    if not code:
        return "근거 미상"
    parts = [p.strip() for p in re.split(r"[+,/ ]+", code) if p.strip()]
    return " · ".join(KEYWORD_KO.get(p.upper(), p) for p in parts)


# ── 견고한 JSON 추출 ─────────────────────────────────────────────────
def _clean(text: str) -> str:
    t = text or ""
    t = re.sub(r"<think>.*?</think>", "", t, flags=re.DOTALL)
    if "</think>" in t:
        t = t.split("</think>")[-1]
    t = re.sub(r"```(?:json)?", "", t).strip().strip("`")
    return t


def _extract_json(text: str):
    text = _clean(text)
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{[\s\S]*\}", text or "")
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return None
    return None


def _norm(d):
    """AI가 돌려준 키를 표준 티커로(btc/KRW_BTC → KRW-BTC)."""
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            fixed = str(k).upper().replace("_", "-")
            if not fixed.startswith("KRW-"):
                fixed = "KRW-" + fixed
            out[fixed] = v
    return out


# ── LLM 호출 ─────────────────────────────────────────────────────────
def _call_deepseek(messages: list) -> tuple[str, str]:
    key = settings.DEEPSEEK_API_KEY
    if not key:
        return "", "DEEPSEEK_API_KEY 미설정"
    try:
        r = requests.post(settings.DEEPSEEK_BASE_URL,
                          headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                          json={"model": settings.DEEPSEEK_MODEL, "messages": messages, "temperature": 0.2},
                          timeout=settings.AI_TIMEOUT_SEC)
        if r.status_code != 200:
            return "", f"HTTP {r.status_code}: {r.text[:150]}"
        return r.json()["choices"][0]["message"]["content"], ""
    except requests.exceptions.Timeout:
        return "", "DeepSeek 타임아웃"
    except Exception as e:
        return "", f"DeepSeek 예외: {e}"


def _call_claude(system: str, user_content: str, model: str, max_tokens: int = 1500) -> tuple[str, str]:
    """Claude 네이티브 Messages API. [레버2] system에 prompt caching 적용(반복 입력 절감)."""
    key = settings.ANTHROPIC_API_KEY
    if not key:
        return "", "ANTHROPIC_API_KEY 미설정"
    try:
        r = requests.post(settings.ANTHROPIC_BASE_URL,
                          headers={"x-api-key": key, "anthropic-version": settings.ANTHROPIC_VERSION,
                                   "content-type": "application/json"},
                          json={"model": model, "max_tokens": max_tokens,
                                "system": [{"type": "text", "text": system,
                                            "cache_control": {"type": "ephemeral"}}],
                                "messages": [{"role": "user", "content": user_content}]},
                          timeout=settings.AI_TIMEOUT_SEC)
        if r.status_code != 200:
            return "", f"HTTP {r.status_code}: {r.text[:150]}"
        data = r.json()
        text = "".join(p.get("text", "") for p in data.get("content", []) if isinstance(p, dict))
        return text, ""
    except requests.exceptions.Timeout:
        return "", "Claude 타임아웃"
    except Exception as e:
        return "", f"Claude 예외: {e}"


# ── 판단 프롬프트(1차/재확인 공용) ───────────────────────────────────
def _recent_for_prompt(ticker: str, cur_price):
    out = []
    for h in db.recent_decisions_for(ticker):
        item = {"ago_min": round((time.time() - float(h["ts_epoch"])) / 60), "decision": h["decision"]}
        if cur_price and h.get("price"):
            try:
                item["price_change_pct_since"] = round((cur_price / float(h["price"]) - 1) * 100, 2)
            except Exception:
                pass
        out.append(item)
    return out


def _build_decide_prompt(snapshot: dict, coins: list) -> tuple[str, str]:
    ap = db.active_prompt()
    system = ap["system_prompt"] if ap else "너는 신중한 단기 트레이더다. BUY/SELL/HOLD를 JSON으로 답하라."
    coins_data, recent = {}, {}
    for c in coins:
        cd = snapshot.get("coins", {}).get(c, {})
        coins_data[c] = cd
        recent[c] = _recent_for_prompt(c, (cd.get("15m", {}) or {}).get("close"))
    payload = {
        "market_sentiment": snapshot.get("market_sentiment"),
        "market_context": snapshot.get("market_context"),
        "coins_data": coins_data,
        "recent_decisions": recent,
        "allowed_reason_keywords": REASON_VOCAB,
        "output_spec": {"각 코인": {"decision": "BUY|SELL|HOLD", "confidence": "high|low",
                                   "next_check_in": "초(정수)", "reason": "허용목록에서 최대 3개, +로 연결"}},
        "coins": coins,
    }
    user = ("아래 지표로 각 코인의 매매를 결정하라. confidence는 확신도 — '명백히 관망'이면 high, "
            "'HOLD 같지만 애매해 상위 모델 재확인 필요'면 low. BUY/SELL은 근거 분명할 때만.\n"
            "⚠ reason은 반드시 allowed_reason_keywords 목록에서 **최대 3개만** 골라 +로 이어라. "
            "목록에 없는 단어·문장·설명·숫자·타임프레임 표기는 절대 쓰지 마라(예: 'RSI_LOW+VOL_UP'). 짧을수록 좋다.\n"
            "반드시 {\"KRW-BTC\":{\"decision\":\"HOLD\",\"confidence\":\"high\",\"next_check_in\":900,\"reason\":\"MIXED\"}, ...} "
            "형태의 JSON 하나로만 답하라.\n" + json.dumps(payload, ensure_ascii=False))
    return system, user


def _deepseek_decide(snapshot: dict, coins: list) -> tuple[dict, str, int]:
    system, user = _build_decide_prompt(snapshot, coins)
    t0 = time.time()
    content, err = _call_deepseek([{"role": "system", "content": system}, {"role": "user", "content": user}])
    ms = int((time.time() - t0) * 1000)
    if err:
        return {}, err, ms
    parsed = _extract_json(content)
    return (_norm(parsed) if isinstance(parsed, dict) else {}), ("" if isinstance(parsed, dict) else "판단 JSON 파싱 실패"), ms


def _claude_decide(snapshot: dict, coins: list, model: str) -> tuple[dict, str, int]:
    system, user = _build_decide_prompt(snapshot, coins)
    t0 = time.time()
    content, err = _call_claude(system, user, model, max_tokens=900)
    ms = int((time.time() - t0) * 1000)
    if err:
        return {}, err, ms
    parsed = _extract_json(content)
    return (_norm(parsed) if isinstance(parsed, dict) else {}), ("" if isinstance(parsed, dict) else "판단 JSON 파싱 실패"), ms


def _base_decide(snapshot: dict, coins: list) -> tuple[dict, str, int]:
    if settings.BASE_BACKEND == "claude":
        return _claude_decide(snapshot, coins, settings.DECISION_MODEL)
    return _deepseek_decide(snapshot, coins)


# ── [레버5] 규칙 사전필터: 명백히 지루한 코인은 LLM 없이 HOLD ──────────
def _is_calm(h1: dict, h4: dict, m15: dict) -> bool:
    """모든 조건이 '조용'할 때만 True. 하나라도 조짐이 있으면 False(→LLM 호출). 보수적으로 짠다."""
    for d in (h1, h4):
        if not d or d.get("rsi") is None or d.get("close") is None \
           or d.get("bb_high") is None or d.get("bb_low") is None:
            return False   # 데이터 부족 → 안전하게 LLM
    if not (45 <= h1["rsi"] <= 60 and 45 <= h4["rsi"] <= 60):   # RSI 중립
        return False
    close, bh, bl = h1["close"], h1["bb_high"], h1["bb_low"]    # 볼밴 가장자리 근접?
    if bh > 0 and bl > 0 and (close >= bh * 0.995 or close <= bl * 1.005):
        return False
    vr = h1.get("vol_ratio")                                    # 거래량 급증/급감?
    if vr is not None and not (0.6 <= vr <= 1.6):
        return False
    rh, rl = h1.get("recent_high"), h1.get("recent_low")        # 최근 고점/저점 근접?
    if rh and close >= rh * 0.99:
        return False
    if rl and close <= rl * 1.01:
        return False
    r15 = (m15 or {}).get("rsi")                                # 단기 급변?
    if r15 is not None and not (40 <= r15 <= 65):
        return False
    return True


def _prefilter(snapshot: dict, coins: list) -> tuple[list, list]:
    if not settings.PREFILTER:
        return list(coins), []
    interesting, boring = [], []
    for c in coins:
        cd = snapshot.get("coins", {}).get(c, {})
        try:
            calm = _is_calm(cd.get("1h", {}) or {}, cd.get("4h", {}) or {}, cd.get("15m", {}) or {})
        except Exception:
            calm = False
        (boring if calm else interesting).append(c)
    return interesting, boring


# ── 신호등 보조지표 ──────────────────────────────────────────────────
def _default_ind():
    return {"volume": {"state": "gray", "label": "거래량", "tooltip": "데이터 부족"},
            "rotation": {"state": "gray", "label": "순환매", "tooltip": "데이터 부족"},
            "onchain": {"state": "gray", "label": "온체인", "tooltip": "연동 예정"}}


def _traffic(snapshot: dict, ticker: str):
    ind = _default_ind()
    try:
        vr = (snapshot.get("coins", {}).get(ticker, {}).get("1h", {}) or {}).get("vol_ratio")
        if vr is not None:
            if vr >= 1.8:
                ind["volume"] = {"state": "green", "label": "거래량", "tooltip": f"평균 대비 {vr:.1f}배 급증"}
            elif vr <= 0.5:
                ind["volume"] = {"state": "red", "label": "거래량", "tooltip": f"평균의 {vr:.1f}배 위축"}
            else:
                ind["volume"] = {"state": "gray", "label": "거래량", "tooltip": f"평균 대비 {vr:.1f}배"}
        btc_rsi = (snapshot.get("market_context") or {}).get("BTC_1d_rsi")
        if btc_rsi is not None and ticker != "KRW-BTC":
            if btc_rsi >= 55:
                ind["rotation"] = {"state": "green", "label": "순환매", "tooltip": f"BTC 강세(1d RSI {btc_rsi})"}
            elif btc_rsi <= 40:
                ind["rotation"] = {"state": "red", "label": "순환매", "tooltip": f"BTC 약세(1d RSI {btc_rsi})"}
    except Exception:
        pass
    return ind


def _clamp_ttl(nci) -> int:
    try:
        v = int(nci)
    except Exception:
        v = settings.SIGNAL_TTL_SEC
    return max(settings.SIGNAL_MIN_TTL_SEC, min(v, settings.SIGNAL_TTL_SEC))


# ── emit(신호 캐시+로그) 헬퍼 ────────────────────────────────────────
def _emit(c, dec, code, nci, snapshot, ts, ds_ms, sn_ms, features):
    px = ((snapshot.get("coins", {}).get(c, {}).get("15m", {}) or {}).get("close"))
    sig = {"ticker": c, "decision": dec, "reasoning": _reason_ko(code), "reason_code": code,
           "ts": ts, "ttl_sec": nci, "next_check_in": nci, "indicators": _traffic(snapshot, c)}
    with _lock:
        _fail_streak[c] = 0
        _cache[c] = (time.time() + nci, sig)
    db.log_decision(c, dec, code, next_check_in=nci, price=px, features=features,
                    deepseek_ms=ds_ms, sonnet_ms=sn_ms, ok=True)


def _emit_fail(c, err, snapshot, ts, ds_ms):
    px = ((snapshot.get("coins", {}).get(c, {}).get("15m", {}) or {}).get("close"))
    with _lock:
        streak = min(_fail_streak.get(c, 0) + 1, 20)
        _fail_streak[c] = streak
        retry = min(settings.SIGNAL_FAIL_RETRY_SEC * (2 ** (streak - 1)), settings.SIGNAL_TTL_SEC)
    sig = {"ticker": c, "decision": "HOLD", "reasoning": f"AI 응답 실패({err}) — 방어적 HOLD",
           "reason_code": "LOW_CONFIDENCE", "ts": ts, "ttl_sec": retry, "next_check_in": retry,
           "indicators": _traffic(snapshot, c)}
    with _lock:
        _cache[c] = (time.time() + retry, sig)
    db.log_decision(c, "HOLD", "LOW_CONFIDENCE", next_check_in=retry, price=px, deepseek_ms=ds_ms, ok=False)


# ── 공개 진입점 ──────────────────────────────────────────────────────
def get_signals(coins: list) -> list:
    now = time.time()
    coins = [c for c in dict.fromkeys(coins) if c]
    with _lock:
        need, wait_for = [], []
        for c in coins:
            hit = _cache.get(c)
            if hit and now < hit[0]:
                continue
            ev = _inflight.get(c)
            if ev is not None:
                wait_for.append(ev); continue
            need.append(c); _inflight[c] = threading.Event()
    for ev in wait_for:
        ev.wait(INFLIGHT_WAIT)
    if need:
        try:
            _analyze(need, time.strftime("%Y-%m-%d %H:%M:%S"))
        finally:
            with _lock:
                for c in need:
                    ev = _inflight.pop(c, None)
                    if ev is not None:
                        ev.set()
    with _lock:
        return [_cache[c][1] for c in coins if c in _cache]


def _analyze(need: list, ts: str):
    snapshot = market_data.collect(need)

    # 1) 규칙 사전필터 — 지루한 코인은 LLM 없이 즉시 HOLD(가장 큰 절감)
    interesting, boring = _prefilter(snapshot, need)
    for c in boring:
        _emit(c, "HOLD", "CALM_NO_SETUP", settings.SIGNAL_TTL_SEC, snapshot, ts,
              ds_ms=None, sn_ms=None, features={"src": "rule"})
    if not interesting:
        return

    # 2) 1차 판단(값싼 base=DeepSeek 기본) — decision + confidence
    base, base_err, base_ms = _base_decide(snapshot, interesting)
    if base_err:
        for c in interesting:
            _emit_fail(c, base_err, snapshot, ts, base_ms)
        return

    # 3) 재확인 대상 선정: BUY/SELL 또는 '확신 없는 HOLD'(또는 이상응답) → Sonnet
    to_esc = []
    for c in interesting:
        it = base.get(c)
        if not (isinstance(it, dict) and it.get("decision") in ("BUY", "SELL", "HOLD")):
            to_esc.append(c); continue
        dec = it["decision"]
        conf = str(it.get("confidence", "")).lower()
        if dec in ("BUY", "SELL"):
            to_esc.append(c)
        elif settings.ESCALATE_UNSURE_HOLD and conf != "high":
            to_esc.append(c)   # 확신 없는 HOLD → Sonnet이 BUY/SELL로 바꿀 수도 있음(놓친 기회 방지)

    esc, esc_ms = {}, 0
    if to_esc:
        esc, esc_err, esc_ms = _claude_decide(snapshot, to_esc, settings.SONNET_MODEL)
        if esc_err:
            esc = {}   # Sonnet 실패해도 base 결과로 진행(전체가 죽지 않게)

    # 4) 최종 결정 emit
    for c in interesting:
        final = None
        if c in to_esc and isinstance(esc.get(c), dict) and esc[c].get("decision") in ("BUY", "SELL", "HOLD"):
            final = esc[c]           # Sonnet 재확인 결과가 최종
            src = "escalated"
        else:
            final = base.get(c)      # base(1차) 결과
            src = settings.BASE_BACKEND
        if isinstance(final, dict) and final.get("decision") in ("BUY", "SELL", "HOLD"):
            code = _sanitize_reason(str(final.get("reason", "") or ""))   # 목록 밖 단어 잘라 최대 3개
            _emit(c, final["decision"], code, _clamp_ttl(final.get("next_check_in")),
                  snapshot, ts, ds_ms=base_ms, sn_ms=(esc_ms if c in to_esc else None),
                  features={"src": src, "ind": snapshot.get("coins", {}).get(c)})
        else:
            _emit_fail(c, base_err or "AI 응답 누락", snapshot, ts, base_ms)
