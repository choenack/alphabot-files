# -*- coding: utf-8 -*-
"""
fable.py — 일요일 자가진화 + 사후 정답지 백필 + 로그 정리 (백그라운드)
=====================================================
[사후 정답지 백필] 판단(decision_log)한 지 1h/4h 지난 건에 대해, 지금 실제 가격으로
                  '그때 판단 뒤 실제로 얼마 올랐/내렸는지(fwd_1h/fwd_4h)'를 채운다 → Fable 학습 재료.
[일요일 자가진화] 주간 학습표본(판단 + 실제결과)을 Claude Fable에게 주고, Sonnet의 '시스템 프롬프트'를
                  더 나은 버전으로 다시 쓰게 한다 → prompt_versions에 새 버전으로 저장·활성화.
[용량관리] 오래된 판단 로그는 자동 삭제(prune)로 하드 포화 방지.
[스케줄러] 백그라운드 스레드가 주기적으로 백필/정리하고, 일요일에 진화를 '주 1회' 실행.
"""
import time
import json
import threading
from datetime import datetime

import db
import market_data
from ai_pipeline import _call_claude, _extract_json
from settings import settings

MIN_SAMPLES_FOR_EVOLUTION = int(__import__("os").environ.get("FABLE_MIN_SAMPLES", "20"))
_SCHED_INTERVAL = 300           # 백필/정리 주기(초)
_HORIZONS = ((3600, "fwd_1h"), (14400, "fwd_4h"))


# ── 사후 정답지 백필 ─────────────────────────────────────────────────
def backfill_forward_returns() -> int:
    """판단 뒤 1h/4h 지난 건의 실제 수익률을 채운다. 반환: 채운 개수."""
    filled = 0
    for horizon, col in _HORIZONS:
        rows = db.rows_awaiting_fill(horizon, col)
        if not rows:
            continue
        # 티커별 현재가를 배치로(중복 제거)
        tickers = list({r["ticker"] for r in rows})
        prices = {}
        for i in range(0, len(tickers), 30):     # 배치 상한 여유
            prices.update(market_data.get_prices(tickers[i:i + 30]))
        for r in rows:
            cur = prices.get(r["ticker"])
            base = r.get("price")
            if cur and base and base > 0:
                ret = round((float(cur) / float(base) - 1.0) * 100, 3)
                db.set_forward_return(r["id"], col, ret)
                filled += 1
    return filled


# ── 일요일 자가진화 ──────────────────────────────────────────────────
def _build_fable_input(samples: list, current_prompt: str) -> str:
    # 학습표본을 간결하게(판단·근거·실제결과)
    compact = [{
        "ticker": s["ticker"], "decision": s["decision"], "reason": s.get("reason"),
        "fwd_1h": s.get("fwd_1h"), "fwd_4h": s.get("fwd_4h"),
    } for s in samples]
    return json.dumps({
        "current_system_prompt": current_prompt,
        "past_decisions_with_outcomes": compact,
        "instruction": ("각 판단의 '실제 이후 수익률(fwd_1h/fwd_4h)'을 보고, 어떤 근거 패턴이 맞고 "
                        "틀렸는지 분석해서 트레이더(Sonnet)의 시스템 프롬프트를 '개선된 새 버전'으로 다시 써라. "
                        "너무 급격히 바꾸지 말고, 명백히 틀린 패턴만 교정하라(과최적화 금지). "
                        "또한 관리자용 '진단 리포트(advisory)'를 한국어 3~5문장으로 써라. 반드시 데이터 근거로: "
                        "①승률/손익 경향 ②HOLD 중 이후 상승한 '놓친 기회' 비율(1차 필터가 너무 보수적인지) "
                        "③잘 맞은/틀린 근거 패턴 ④관리자가 검토할 권고(예: 필터 완화, escalation 재검토). "
                        "인프라 설정을 네가 바꾸지 말고 '권고'만 하라. "
                        "반드시 {\"system_prompt\": \"...개선된 전체 프롬프트...\", \"summary\": \"바꾼 요지(한 문장)\", "
                        "\"advisory\": \"...관리자용 진단 리포트...\"} 형태의 JSON 하나로만 답하라."),
    }, ensure_ascii=False)


def run_weekly_evolution(force: bool = False) -> dict:
    """학습표본으로 Sonnet 프롬프트를 진화시킨다. 표본이 적으면 건너뜀.
    표본은 설정 간격(기본 30일) 내에서 '최대 3000개'로 상한 → 데이터가 쌓여도 비용은 일정."""
    win = int(getattr(settings, "FABLE_INTERVAL_DAYS", 30))
    samples = db.training_samples(since_days=win, need_filled=True, limit=3000)
    if not force and len(samples) < MIN_SAMPLES_FOR_EVOLUTION:
        return {"ok": False, "reason": f"학습표본 부족({len(samples)}/{MIN_SAMPLES_FOR_EVOLUTION})"}
    ap = db.active_prompt()
    cur_prompt = ap["system_prompt"] if ap else ""
    sys_msg = ("너는 퀀트 트레이딩 시스템의 자가학습 담당이다. 과거 판단과 그 '실제 결과'를 근거로 "
               "트레이더의 시스템 프롬프트를 신중하게 개선한다. 반드시 JSON으로만 답한다.")
    text, err = _call_claude(sys_msg, _build_fable_input(samples, cur_prompt),
                             settings.FABLE_MODEL, max_tokens=3000)
    if err:
        return {"ok": False, "reason": f"Fable 호출 실패: {err}"}
    parsed = _extract_json(text)
    if not isinstance(parsed, dict) or not parsed.get("system_prompt"):
        return {"ok": False, "reason": "Fable 응답 파싱 실패"}
    new_prompt = str(parsed["system_prompt"]).strip()
    summary = str(parsed.get("summary", "")).strip() or "자가진화"
    advisory = str(parsed.get("advisory", "")).strip()
    if len(new_prompt) < 50:
        return {"ok": False, "reason": "새 프롬프트가 비정상적으로 짧음(적용 안 함)"}
    vid = db.add_prompt_version(new_prompt, summary, author="fable",
                                sample_count=len(samples), activate=True)
    # 관리자용 진단 리포트 저장(대시보드 진화 탭에 표시)
    if advisory:
        db.set_config("fable_advisory", advisory)
        db.set_config("fable_advisory_at", datetime.now().isoformat())
    return {"ok": True, "version_id": vid, "summary": summary,
            "advisory": advisory, "samples": len(samples)}


def _iso_week(dt: datetime) -> str:
    y, w, _ = dt.isocalendar()
    return f"{y}-W{w:02d}"


def maybe_run_evolution():
    """설정 간격(기본 30일=월1회)마다 1회 진화 실행. FABLE_ENABLED=0이면 자동 진화 끔(수동은 가능)."""
    if not getattr(settings, "FABLE_ENABLED", True):
        return
    interval = int(getattr(settings, "FABLE_INTERVAL_DAYS", 30)) * 86400
    now = time.time()
    last_raw = db.get_config("fable_last_run", "")
    if not last_raw:
        # 최초 도입: 지금부터 카운트 시작(배포 즉시 실행 방지 → 첫 자동 진화는 interval 뒤).
        db.set_config("fable_last_run", str(now))
        return
    try:
        last = float(last_raw)
    except Exception:
        last = 0.0
    if now - last < interval:
        return
    res = run_weekly_evolution()
    db.set_config("fable_last_run", str(now))   # 성공/실패 무관 표시(무한 재시도 방지)
    db.set_config("fable_last_result", json.dumps(res, ensure_ascii=False))


# ── 백그라운드 스케줄러 ──────────────────────────────────────────────
_started = False


def _loop():
    # 시작 직후 1회 백필
    try:
        backfill_forward_returns()
    except Exception:
        pass
    last_prune = 0.0
    while True:
        time.sleep(_SCHED_INTERVAL)
        try:
            backfill_forward_returns()
        except Exception:
            pass
        try:
            maybe_run_evolution()
        except Exception:
            pass
        # 하루 1회 정리 + 만료임박 관리자 알림
        if time.time() - last_prune > 86400:
            last_prune = time.time()
            try:
                db.prune_old_logs()
            except Exception:
                pass
            try:
                import notify
                from settings import settings as _s
                rows = db.expiring_soon(_s.EXPIRE_SOON_DAYS)
                notify.on_expiring(rows, _s.EXPIRE_SOON_DAYS)
            except Exception:
                pass


def start_scheduler():
    global _started
    if _started:
        return
    _started = True
    threading.Thread(target=_loop, daemon=True, name="fable-scheduler").start()
