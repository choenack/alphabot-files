# -*- coding: utf-8 -*-
"""
fable.py — 일요일 자가진화 + 사후 정답지 백필 + 로그 정리 (백그라운드)
=====================================================
[사후 정답지 백필] 판단(decision_log)한 지 1h/4h 지난 건에 대해, 지금 실제 가격으로
                  '그때 판단 뒤 실제로 얼마 올랐/내렸는지(fwd_1h/fwd_4h)'를 채운다 → Fable 학습 재료.
[일요일 자가진화] 주간 학습표본(판단 + 실제결과)을 Claude Fable에게 주고, Sonnet의 '시스템 프롬프트'를
                  더 나은 버전으로 다시 쓰게 한다 → prompt_versions에 새 버전으로 저장·활성화.
[용량관리] 오래된 판단 로그는 자동 삭제(prune)로 하드 포화 방지.
[스케줄러] 백그라운드 스레드가 주기적으로 백필/정리하고, 일요일에 진화를 '주 1회' 실행.
"""
import time
import json
import threading
from datetime import datetime

import db
import market_data
from ai_pipeline import _call_claude, _extract_json
from settings import settings

MIN_SAMPLES_FOR_EVOLUTION = int(__import__("os").environ.get("FABLE_MIN_SAMPLES", "20"))
_SCHED_INTERVAL = 300           # 백필/정리 주기(초)
_HORIZONS = ((3600, "fwd_1h"), (14400, "fwd_4h"))


# ── 사후 정답지 백필 ─────────────────────────────────────────────────
def backfill_forward_returns() -> int:
    """판단 뒤 1h/4h 지난 건의 실제 수익률을 채운다. 반환: 채운 개수."""
    filled = 0
    for horizon, col in _HORIZONS:
        rows = db.rows_awaiting_fill(horizon, col)
        if not rows:
            continue
        # 티커별 현재가를 배치로(중복 제거)
        tickers = list({r["ticker"] for r in rows})
        prices = {}
        for i in range(0, len(tickers), 30):     # 배치 상한 여유
            prices.update(market_data.get_prices(tickers[i:i + 30]))
        for r in rows:
            cur = prices.get(r["ticker"])
            base = r.get("price")
            if cur and base and base > 0:
                ret = round((float(cur) / float(base) - 1.0) * 100, 3)
                db.set_forward_return(r["id"], col, ret)
                filled += 1
    return filled


# ── 일요일 자가진화 ──────────────────────────────────────────────────
def _build_fable_input(samples: list, current_prompt: str) -> str:
    # 학습표본을 간결하게(판단·근거·실제결과)
    compact = [{
        "ticker": s["ticker"], "decision": s["decision"], "reason": s.get("reason"),
        "fwd_1h": s.get("fwd_1h"), "fwd_4h": s.get("fwd_4h"),
    } for s in samples]
    return json.dumps({
        "current_system_prompt": current_prompt,
        "past_decisions_with_outcomes": compact,
        "instruction": ("각 판단의 '실제 이후 수익률(fwd_1h/fwd_4h)'을 보고, 어떤 근거 패턴이 맞고 "
                        "틀렸는지 분석해서 트레이더(Sonnet)의 시스템 프롬프트를 '개선된 새 버전'으로 다시 써라. "
                        "너무 급격히 바꾸지 말고, 명백히 틀린 패턴만 교정하라(과최적화 금지). "
                        "반드시 {\"system_prompt\": \"...개선된 전체 프롬프트...\", \"summary\": \"이번에 바꾼 요지(한 문장)\"} "
                        "형태의 JSON 하나로만 답하라."),
    }, ensure_ascii=False)


def run_weekly_evolution(force: bool = False) -> dict:
    """주간 학습표본으로 Sonnet 프롬프트를 진화시킨다. 표본이 적으면 건너뜀."""
    samples = db.training_samples(since_days=7, need_filled=True, limit=3000)
    if not force and len(samples) < MIN_SAMPLES_FOR_EVOLUTION:
        return {"ok": False, "reason": f"학습표본 부족({len(samples)}/{MIN_SAMPLES_FOR_EVOLUTION})"}
    ap = db.active_prompt()
    cur_prompt = ap["system_prompt"] if ap else ""
    sys_msg = ("너는 퀀트 트레이딩 시스템의 자가학습 담당이다. 과거 판단과 그 '실제 결과'를 근거로 "
               "트레이더의 시스템 프롬프트를 신중하게 개선한다. 반드시 JSON으로만 답한다.")
    text, err = _call_claude(sys_msg, _build_fable_input(samples, cur_prompt),
                             settings.FABLE_MODEL, max_tokens=3000)
    if err:
        return {"ok": False, "reason": f"Fable 호출 실패: {err}"}
    parsed = _extract_json(text)
    if not isinstance(parsed, dict) or not parsed.get("system_prompt"):
        return {"ok": False, "reason": "Fable 응답 파싱 실패"}
    new_prompt = str(parsed["system_prompt"]).strip()
    summary = str(parsed.get("summary", "")).strip() or "주간 자가진화"
    if len(new_prompt) < 50:
        return {"ok": False, "reason": "새 프롬프트가 비정상적으로 짧음(적용 안 함)"}
    vid = db.add_prompt_version(new_prompt, summary, author="fable",
                                sample_count=len(samples), activate=True)
    return {"ok": True, "version_id": vid, "summary": summary, "samples": len(samples)}


def _iso_week(dt: datetime) -> str:
    y, w, _ = dt.isocalendar()
    return f"{y}-W{w:02d}"


def maybe_run_evolution():
    """일요일이면 이번 주 아직 안 돌렸을 때 1회 진화 실행."""
    now = datetime.now()
    if now.weekday() != 6:          # 6 = 일요일
        return
    wk = _iso_week(now)
    if db.get_config("fable_last_week", "") == wk:
        return                       # 이번 주 이미 실행함
    res = run_weekly_evolution()
    db.set_config("fable_last_week", wk)   # 성공/실패 무관 표시(무한 재시도 방지)
    db.set_config("fable_last_result", json.dumps(res, ensure_ascii=False))


# ── 백그라운드 스케줄러 ──────────────────────────────────────────────
_started = False


def _loop():
    # 시작 직후 1회 백필
    try:
        backfill_forward_returns()
    except Exception:
        pass
    last_prune = 0.0
    while True:
        time.sleep(_SCHED_INTERVAL)
        try:
            backfill_forward_returns()
        except Exception:
            pass
        try:
            maybe_run_evolution()
        except Exception:
            pass
        # 하루 1회 정리 + 만료임박 관리자 알림
        if time.time() - last_prune > 86400:
            last_prune = time.time()
            try:
                db.prune_old_logs()
            except Exception:
                pass
            try:
                import notify
                from settings import settings as _s
                rows = db.expiring_soon(_s.EXPIRE_SOON_DAYS)
                notify.on_expiring(rows, _s.EXPIRE_SOON_DAYS)
            except Exception:
                pass


def start_scheduler():
    global _started
    if _started:
        return
    _started = True
    threading.Thread(target=_loop, daemon=True, name="fable-scheduler").start()
