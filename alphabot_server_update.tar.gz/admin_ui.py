# -*- coding: utf-8 -*-
"""
admin_ui.py — 관리자 웹 대시보드 (단일 HTML · 탭 구조 · 모바일 최적화)
=====================================================
브라우저/폰에서 http://<서버>:8000/admin 접속 → 관리자 로그인 → 탭으로 관리:
  📊 현황   : 회원/구독/매출 KPI, 서버 점검 스위치, 만료 임박
  👥 회원   : 검색·목록·상세, [구독부여·강제해지·잠금·구독취소·비번리셋·삭제]
  💳 결제   : 대기중 승인/거절 + 결제 내역
  🤖 AI     : 최근 판단 로그(DS/SN)
  🧬 진화   : Fable 프롬프트 진화 이력 + 수동 실행
  ⚙️ 설정   : 현재 서버 설정/알림 연결 상태
JWT 토큰은 localStorage 저장(새로고침해도 로그인 유지). 모든 표는 좁은 화면에서 카드로 표시.
"""

ADMIN_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>AlphaBot 관리자</title>
<style>
:root{--bg:#0b0e14;--card:#141922;--bd:#232a36;--tx:#e6e9ef;--mut:#8a93a6;--acc:#3b82f6;--g:#16a34a;--r:#ef4444;--y:#d97706}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);font-family:system-ui,'Malgun Gothic',sans-serif;font-size:14px;-webkit-text-size-adjust:100%}
.wrap{max-width:1000px;margin:0 auto;padding:12px}
h1{font-size:18px;margin:0}h2{font-size:13px;color:var(--mut);margin:16px 2px 8px;font-weight:600}
.card{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:12px;margin-bottom:10px}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.sp{flex:1}.mut{color:var(--mut)}.hidden{display:none!important}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px}
.kpi{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:11px}
.kpi .l{color:var(--mut);font-size:11px}.kpi .v{font-size:20px;font-weight:800;margin-top:3px}
button{background:var(--acc);color:#fff;border:0;border-radius:8px;padding:8px 11px;cursor:pointer;font-size:13px;font-weight:600}
button.ghost{background:#1e2632;color:var(--tx);border:1px solid var(--bd)}
button.g{background:var(--g)}button.r{background:var(--r)}button.y{background:var(--y)}
button.sm{padding:6px 9px;font-size:12px}button:disabled{opacity:.5;cursor:default}
input,select{background:#0f141c;color:var(--tx);border:1px solid var(--bd);border-radius:8px;padding:8px;font-size:14px}
.tag{padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700;white-space:nowrap}
.b-buy{background:rgba(22,163,74,.18);color:#4ade80}.b-sell{background:rgba(239,68,68,.18);color:#f87171}
.b-hold{background:rgba(138,147,166,.18);color:#cbd5e1}.b-on{background:rgba(22,163,74,.18);color:#4ade80}
.b-off{background:rgba(239,68,68,.18);color:#f87171}.b-warn{background:rgba(217,119,6,.2);color:#fbbf24}
/* 목록 카드(모바일 친화) */
.li{display:flex;align-items:center;gap:8px;padding:10px 4px;border-bottom:1px solid var(--bd)}
.li:last-child{border-bottom:0}.li b{font-size:14px}
/* 탭바 */
.tabs{position:sticky;top:0;z-index:5;background:var(--bg);display:flex;gap:6px;overflow-x:auto;padding:8px 0;border-bottom:1px solid var(--bd);-webkit-overflow-scrolling:touch}
.tabs button{background:transparent;color:var(--mut);border:1px solid transparent;border-radius:20px;padding:7px 13px;white-space:nowrap;font-weight:700}
.tabs button.on{background:#1e2632;color:var(--tx);border-color:var(--bd)}
/* AI 로그만 가로 스크롤 표 */
.tblwrap{overflow:auto;max-height:60vh}
table{width:100%;border-collapse:collapse;font-size:12px}th,td{text-align:left;padding:6px 7px;border-bottom:1px solid var(--bd);white-space:nowrap}
th{color:var(--mut);font-weight:600}
/* 로그인 */
#login{max-width:340px;margin:14vh auto}#login input{width:100%;margin:6px 0}
/* 모달(회원 상세) */
.ov{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:flex-end;justify-content:center;z-index:20}
.sheet{background:var(--card);border:1px solid var(--bd);border-radius:16px 16px 0 0;width:100%;max-width:560px;max-height:88vh;overflow:auto;padding:16px}
@media(min-width:600px){.ov{align-items:center}.sheet{border-radius:16px}}
.act{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}
.toast{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);background:#1e2632;border:1px solid var(--bd);border-radius:10px;padding:10px 16px;font-size:13px;z-index:40;opacity:0;transition:.2s}
.toast.show{opacity:1}
</style></head><body>

<div id="login" class="card">
  <h1>🛡️ AlphaBot 관리자</h1>
  <p class="mut" style="font-size:12px">관리자 계정으로 로그인하세요.</p>
  <input id="u" placeholder="아이디" autocomplete="username">
  <input id="p" type="password" placeholder="비밀번호" autocomplete="current-password">
  <button onclick="login()" style="width:100%;margin-top:6px">로그인</button>
  <div id="lerr" class="mut" style="color:var(--r);margin-top:8px;font-size:12px"></div>
</div>

<div id="dash" class="wrap hidden">
  <div class="row" style="margin-bottom:6px">
    <h1>🛡️ AlphaBot</h1><span class="mut" id="who"></span><div class="sp"></div>
    <button class="ghost sm" onclick="loadTab()">↻</button>
    <button class="ghost sm" onclick="logout()">로그아웃</button>
  </div>

  <div class="tabs" id="tabs">
    <button data-t="home" class="on" onclick="tab('home')">📊 현황</button>
    <button data-t="members" onclick="tab('members')">👥 회원</button>
    <button data-t="pay" onclick="tab('pay')">💳 결제</button>
    <button data-t="ai" onclick="tab('ai')">🤖 AI</button>
    <button data-t="eval" onclick="tab('eval')">🧬 진화</button>
    <button data-t="cfg" onclick="tab('cfg')">⚙️ 설정</button>
  </div>

  <!-- 현황 -->
  <div id="p-home" class="pane">
    <h2>현황</h2>
    <div class="grid" id="kpis"></div>
    <h2>서버 제어</h2>
    <div class="card row">
      <span>점검 모드:</span><span id="mnt"></span>
      <button id="mbtn" class="sm" onclick="toggleMnt()">전환</button>
      <span class="mut" style="font-size:11px">(켜면 신호 일시중지 · 클라는 손절감시만 유지)</span>
    </div>
    <h2>구독 만료 임박</h2>
    <div class="card" id="expiring"><span class="mut">—</span></div>
  </div>

  <!-- 회원 -->
  <div id="p-members" class="pane hidden">
    <h2>구독 부여/연장</h2>
    <div class="card row">
      <input id="su" placeholder="아이디" style="flex:1;min-width:120px">
      <select id="st"><option value="AUTO">AUTO</option><option value="DATA_ONLY">DATA_ONLY</option></select>
      <input id="sd" type="number" value="30" style="width:64px"><span class="mut">일</span>
      <button class="g sm" onclick="subUser()">부여</button>
    </div>
    <div id="smsg" class="mut" style="font-size:12px;margin:2px"></div>
    <h2>회원 <input id="q" placeholder="🔍 아이디 검색" oninput="loadMembers()" style="margin-left:6px;width:150px"></h2>
    <div class="card" id="members"><span class="mut">—</span></div>
  </div>

  <!-- 결제 -->
  <div id="p-pay" class="pane hidden">
    <h2>대기중 결제신청</h2>
    <div class="card" id="pending"><span class="mut">—</span></div>
    <h2>결제 내역</h2>
    <div class="card" id="payhist"><span class="mut">—</span></div>
  </div>

  <!-- AI -->
  <div id="p-ai" class="pane hidden">
    <h2>AI 가동 로그 (최근 판단)</h2>
    <div class="card tblwrap"><table id="logs"><thead><tr><th>시각</th><th>코인</th><th>판단</th><th>근거</th><th>주기</th><th>DS/SN(ms)</th></tr></thead><tbody></tbody></table></div>
  </div>

  <!-- 진화 -->
  <div id="p-eval" class="pane hidden">
    <h2>Fable 프롬프트 진화</h2>
    <div class="card row">
      <button class="ghost" onclick="runFable()">🧬 Fable 자가진화 지금 실행</button>
      <span class="mut" style="font-size:11px">표본 적으면 자동 건너뜀</span>
    </div>
    <div class="card tblwrap"><table id="prompts"><thead><tr><th>버전</th><th>작성</th><th>요지</th><th>표본</th><th>활성</th><th>생성</th></tr></thead><tbody></tbody></table></div>
  </div>

  <!-- 설정 -->
  <div id="p-cfg" class="pane hidden">
    <h2>서버 설정 · 연결 상태</h2>
    <div class="card" id="cfg"><span class="mut">—</span></div>
    <p class="mut" style="font-size:11px;margin-top:8px">※ 비밀키·모델·텔레그램 토큰은 서버 .env 에서만 변경합니다(보안). 여기선 연결 여부만 표시.</p>
  </div>

  <p class="mut" style="text-align:center;margin:20px 0;font-size:11px">AlphaBot AWS · 관리자</p>
</div>

<div id="modal"></div>
<div id="toast" class="toast"></div>

<script>
var TK = localStorage.getItem('ab_admin_tk') || '';
var CUR = 'home';
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
function won(v){return (Number(v||0)).toLocaleString('ko-KR')+'원'}
function toast(m){var t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(function(){t.classList.remove('show')},1800)}
async function api(path, opts){
  opts=opts||{};opts.headers=Object.assign({'Authorization':'Bearer '+TK},opts.headers||{});
  var r=await fetch(path,opts);
  if(r.status===401||r.status===403){ if(!document.getElementById('dash').classList.contains('hidden')) logout(); throw new Error('auth'); }
  return r;
}
async function jget(p){return (await api(p)).json()}
async function jpost(p,b){return (await api(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b||{})})).json()}

async function login(){
  var u=document.getElementById('u').value.trim(),p=document.getElementById('p').value;
  var e=document.getElementById('lerr');e.textContent='';
  try{
    var r=await fetch('/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
    var d=await r.json().catch(function(){return{}});
    if(!r.ok){ e.textContent=r.status===403?'차단된 계정입니다.':'아이디/비밀번호가 틀립니다.'; return; }
    if(d.role!=='admin'){ e.textContent='관리자 계정이 아닙니다.'; return; }
    TK=d.token; localStorage.setItem('ab_admin_tk',TK);
    document.getElementById('who').textContent='· '+esc(d.username);
    show(); tab('home');
  }catch(err){ e.textContent='서버에 연결할 수 없습니다.'; }
}
function show(){ document.getElementById('login').classList.add('hidden'); document.getElementById('dash').classList.remove('hidden'); }
function logout(){ TK=''; localStorage.removeItem('ab_admin_tk'); document.getElementById('dash').classList.add('hidden'); document.getElementById('login').classList.remove('hidden'); }

function tab(t){
  CUR=t;
  var tb=document.getElementById('tabs').querySelectorAll('button');
  tb.forEach(function(b){ b.classList.toggle('on', b.getAttribute('data-t')===t); });
  ['home','members','pay','ai','eval','cfg'].forEach(function(x){
    document.getElementById('p-'+x).classList.toggle('hidden', x!==t);
  });
  loadTab();
}
function loadTab(){
  try{
    if(CUR==='home'){ loadStats(); loadExpiring(); }
    else if(CUR==='members'){ loadMembers(); }
    else if(CUR==='pay'){ loadPending(); loadPayHist(); }
    else if(CUR==='ai'){ loadLogs(); }
    else if(CUR==='eval'){ loadPrompts(); }
    else if(CUR==='cfg'){ loadCfg(); }
  }catch(e){}
}

// ── 현황 ──
async function loadStats(){
  var s=await jget('/admin/stats');
  var K=[['회원수',s.members],['활성 구독',s.active_subs],['AUTO 구독',s.auto_subs],
         ['이달 매출',won(s.revenue_month)],['대기 결제',s.pending_payments],['만료 임박',s.expiring_soon],
         ['강제해지',s.banned],['판단 로그',s.decision_logs],['프롬프트 v',s.prompt_version]];
  document.getElementById('kpis').innerHTML=K.map(function(k){return '<div class="kpi"><div class="l">'+k[0]+'</div><div class="v">'+(k[1]==null?'-':k[1])+'</div></div>'}).join('');
  var on=s.maintenance; document.getElementById('mnt').innerHTML='<span class="tag '+(on?'b-off':'b-on')+'">'+(on?'점검중 ON':'정상 OFF')+'</span>';
}
async function toggleMnt(){
  var on=document.getElementById('mnt').textContent.indexOf('ON')>=0;
  await jpost('/admin/maintenance',{on:!on}); loadStats();
}
async function loadExpiring(){
  var j=await jget('/admin/expiring');
  var el=document.getElementById('expiring');
  if(!j.expiring.length){ el.innerHTML='<span class="mut">'+j.days+'일 이내 만료 예정 없음</span>'; return; }
  el.innerHTML=j.expiring.map(function(u){
    return '<div class="li"><b>'+esc(u.username)+'</b><span class="tag b-buy">'+esc(u.tier||'')+'</span><span class="sp"></span><span class="mut">~'+String(u.subscription_expiry||'').slice(0,10)+'</span><button class="g sm" onclick="quickGrant(\''+esc(u.username)+'\')">연장</button></div>';
  }).join('');
}
function quickGrant(u){ openUser(u); }

// ── 회원 ──
async function subUser(){
  var u=document.getElementById('su').value.trim(),t=document.getElementById('st').value,d=document.getElementById('sd').value;
  var m=document.getElementById('smsg');m.textContent='';
  if(!u){ m.textContent='아이디를 입력하세요'; return; }
  try{ var j=await jpost('/admin/subscribe',{username:u,tier:t,days:Number(d)});
    m.style.color='#4ade80'; m.textContent='✓ '+u+' → '+j.tier+' ('+String(j.expiry).slice(0,10)+'까지)'; loadMembers();
  }catch(e){ m.style.color='#f87171'; m.textContent='실패: 그 아이디가 없습니다'; }
}
async function loadMembers(){
  var q=document.getElementById('q').value.trim();
  var j=await jget('/admin/users?q='+encodeURIComponent(q));
  var el=document.getElementById('members');
  if(!j.users.length){ el.innerHTML='<span class="mut">회원 없음</span>'; return; }
  el.innerHTML=j.users.map(function(u){
    var st=u.banned?'<span class="tag b-off">해지</span>':(u.locked?'<span class="tag b-warn">잠김</span>':'<span class="tag b-on">정상</span>');
    var sub=u.is_subscribed?'<span class="tag b-buy">'+esc(u.tier||'')+'</span>':'<span class="tag b-hold">미구독</span>';
    return '<div class="li" onclick="openUser(\''+esc(u.username)+'\')" style="cursor:pointer">'+
      '<b>'+esc(u.username)+'</b>'+(u.role==='admin'?' 👑':'')+' '+sub+'<span class="sp"></span>'+st+
      '<span class="mut" style="font-size:11px">'+String(u.subscription_expiry||'').slice(0,10)+' ›</span></div>';
  }).join('');
}
async function openUser(username){
  var d;
  try{ d=await jget('/admin/user?username='+encodeURIComponent(username)); }catch(e){ return; }
  var isAdmin=d.role==='admin';
  var st=d.banned?'<span class="tag b-off">강제해지</span>':(d.locked?'<span class="tag b-warn">잠김</span>':'<span class="tag b-on">정상</span>');
  var sub=d.active?'<span class="tag b-buy">'+esc(d.tier||'')+' 구독중</span>':'<span class="tag b-hold">미구독</span>';
  var ev=(d.subscription_events||[]).slice(0,6).map(function(e){return '<div class="mut" style="font-size:12px">· '+esc(e.action)+' '+esc(e.tier||'')+' '+(e.days?('('+e.days+'일)'):'')+' — '+String(e.created_at||'').slice(0,16)+'</div>'}).join('')||'<div class="mut" style="font-size:12px">이력 없음</div>';
  var pays=(d.payments||[]).slice(0,6).map(function(p){return '<div class="mut" style="font-size:12px">· #'+p.id+' '+won(p.amount)+' '+esc(p.tier||'')+' ['+esc(p.status)+'] '+String(p.requested_at||'').slice(0,16)+'</div>'}).join('')||'<div class="mut" style="font-size:12px">결제 없음</div>';
  var actions = isAdmin
    ? '<div class="mut" style="margin-top:10px">👑 관리자 계정 — 차단/삭제 불가</div>'
    : '<div class="act">'+
        '<button class="g sm" onclick="doGrant(\''+esc(username)+'\')">구독 부여/연장</button>'+
        '<button class="y sm" onclick="doCancel(\''+esc(username)+'\')">구독 취소</button>'+
        (d.locked?'<button class="ghost sm" onclick="doLock(\''+esc(username)+'\',false)">잠금 해제</button>':'<button class="ghost sm" onclick="doLock(\''+esc(username)+'\',true)">계정 잠금</button>')+
        (d.banned?'<button class="ghost sm" onclick="doBan(\''+esc(username)+'\',false)">해지 복구</button>':'<button class="r sm" onclick="doBan(\''+esc(username)+'\',true)">강제 해지</button>')+
        '<button class="ghost sm" onclick="doReset(\''+esc(username)+'\')">비번 리셋</button>'+
        '<button class="r sm" onclick="doDelete(\''+esc(username)+'\')">회원 삭제</button>'+
      '</div>';
  document.getElementById('modal').innerHTML=
    '<div class="ov" onclick="if(event.target===this)closeModal()"><div class="sheet">'+
      '<div class="row"><h1 style="font-size:16px">'+esc(username)+(isAdmin?' 👑':'')+'</h1><div class="sp"></div><button class="ghost sm" onclick="closeModal()">✕</button></div>'+
      '<div class="row" style="margin:8px 0">'+sub+st+'</div>'+
      '<div class="mut" style="font-size:12px">실명: '+esc(d.real_name||'-')+' · 가입: '+String(d.created_at||'').slice(0,10)+'</div>'+
      '<div class="mut" style="font-size:12px">만료: '+(d.subscription_expiry?String(d.subscription_expiry).slice(0,16):'-')+'</div>'+
      actions+
      '<h2>구독 이력</h2>'+ev+
      '<h2>결제 이력</h2>'+pays+
    '</div></div>';
}
function closeModal(){ document.getElementById('modal').innerHTML=''; }
async function doGrant(u){
  var t=prompt('등급 (AUTO 또는 DATA_ONLY)','AUTO'); if(!t) return;
  var d=prompt('며칠?','30'); if(!d) return;
  try{ await jpost('/admin/subscribe',{username:u,tier:t.trim(),days:Number(d)}); toast('구독 부여 완료'); closeModal(); loadTab(); }catch(e){ toast('실패'); }
}
async function doCancel(u){ if(!confirm(u+' 구독을 즉시 취소할까요?'))return; try{ await jpost('/admin/subscription/cancel',{username:u}); toast('구독 취소됨'); closeModal(); loadTab(); }catch(e){ toast('실패'); } }
async function doLock(u,on){ try{ await jpost('/admin/user/lock',{username:u,on:on}); toast(on?'계정 잠금':'잠금 해제'); openUser(u); loadMembers(); }catch(e){ toast('실패'); } }
async function doBan(u,on){ if(on&&!confirm(u+' 강제해지할까요? (구독취소+재가입 제한))'))return; try{ await jpost('/admin/user/ban',{username:u,on:on}); toast(on?'강제 해지됨':'복구됨'); openUser(u); loadMembers(); }catch(e){ toast('실패'); } }
async function doReset(u){ var pw=prompt('새 비밀번호(6자 이상)'); if(!pw)return; try{ await jpost('/admin/user/reset_password',{username:u,new_password:pw}); toast('비번 리셋 완료'); }catch(e){ toast('실패(6자 이상?)'); } }
async function doDelete(u){ if(!confirm(u+' 회원을 완전 삭제할까요? 되돌릴 수 없습니다.'))return; try{ await jpost('/admin/user/delete',{username:u}); toast('삭제됨'); closeModal(); loadMembers(); }catch(e){ toast('실패'); } }

// ── 결제 ──
async function loadPending(){
  var j=await jget('/admin/payments/pending');
  var el=document.getElementById('pending');
  if(!j.pending.length){ el.innerHTML='<span class="mut">대기중 결제신청 없음</span>'; return; }
  el.innerHTML=j.pending.map(function(p){
    return '<div class="li"><b>'+esc(p.username)+'</b><span class="tag b-buy">'+esc(p.tier)+'</span><span>'+won(p.amount)+'</span><span class="sp"></span>'+
      '<button class="g sm" onclick="approve('+p.id+')">승인</button><button class="r sm" onclick="reject('+p.id+')">거절</button></div>';
  }).join('');
}
async function approve(id){ try{ var r=await jpost('/admin/payments/approve',{request_id:id,days:30}); toast('승인: '+r.tier+' ~'+String(r.expiry).slice(0,10)); loadPending(); loadPayHist(); }catch(e){ toast('실패'); } }
async function reject(id){ if(!confirm('이 결제신청을 거절할까요?'))return; try{ await jpost('/admin/payments/reject',{request_id:id}); toast('거절됨'); loadPending(); loadPayHist(); }catch(e){ toast('실패'); } }
async function loadPayHist(){
  var j=await jget('/admin/payments/history?limit=60');
  var el=document.getElementById('payhist');
  if(!j.history.length){ el.innerHTML='<span class="mut">결제 내역 없음</span>'; return; }
  el.innerHTML=j.history.map(function(p){
    var c=p.status==='approved'?'b-on':(p.status==='rejected'?'b-off':'b-warn');
    return '<div class="li"><b>'+esc(p.username||'')+'</b><span>'+won(p.amount)+'</span><span class="tag '+c+'">'+esc(p.status)+'</span><span class="sp"></span><span class="mut" style="font-size:11px">'+String(p.requested_at||'').slice(0,16)+'</span></div>';
  }).join('');
}

// ── AI 로그 ──
async function loadLogs(){
  var j=await jget('/admin/logs?limit=80');
  var b=document.querySelector('#logs tbody');
  b.innerHTML=j.logs.map(function(l){
    var cls=l.decision==='BUY'?'b-buy':(l.decision==='SELL'?'b-sell':'b-hold');
    return '<tr><td class="mut">'+String(l.ts||'').slice(5,19)+'</td><td>'+esc(l.ticker)+'</td><td><span class="tag '+cls+'">'+esc(l.decision)+'</span></td><td class="mut">'+esc(l.reason||'')+'</td><td>'+(l.next_check_in||'-')+'s</td><td class="mut">'+(l.deepseek_ms||'-')+'/'+(l.sonnet_ms||'-')+'</td></tr>';
  }).join('')||'<tr><td colspan="6" class="mut">아직 판단 로그 없음</td></tr>';
}

// ── 진화 ──
async function runFable(){
  if(!confirm('Fable 자가진화를 지금 실행할까요? (Claude Fable API 호출)'))return;
  try{ var r=await jpost('/admin/evolve'); alert(r.ok?('완료: '+r.summary+' (표본 '+r.samples+'개)'):('건너뜀: '+r.reason)); loadPrompts(); }catch(e){ toast('실패'); }
}
async function loadPrompts(){
  var j=await jget('/admin/prompts');
  var b=document.querySelector('#prompts tbody');
  b.innerHTML=j.versions.map(function(v){
    return '<tr><td><b>v'+v.version+'</b></td><td>'+esc(v.author)+'</td><td>'+esc(v.summary||'')+'</td><td>'+(v.sample_count||0)+'</td><td>'+(v.active?'<span class="tag b-on">활성</span>':'')+'</td><td class="mut">'+String(v.created_at||'').slice(0,16)+'</td></tr>';
  }).join('');
}

// ── 설정 ──
async function loadCfg(){
  var h=await (await fetch('/health')).json();
  var c=h.config||{};
  function yn(b){return b?'<span class="tag b-on">연결됨</span>':'<span class="tag b-off">미설정</span>'}
  document.getElementById('cfg').innerHTML=
    '<div class="li"><span>Claude(Anthropic) 키</span><span class="sp"></span>'+yn(c.anthropic_key_set)+'</div>'+
    '<div class="li"><span>DeepSeek 키</span><span class="sp"></span>'+yn(c.deepseek_key_set)+'</div>'+
    '<div class="li"><span>관리자 텔레그램 알림</span><span class="sp"></span>'+yn(c.admin_telegram_set)+'</div>'+
    '<div class="li"><span>1차 판단 모델</span><span class="sp"></span><span class="mut">'+esc(c.deepseek_model||'')+'</span></div>'+
    '<div class="li"><span>재확인 모델</span><span class="sp"></span><span class="mut">'+esc(c.sonnet_model||'')+'</span></div>'+
    '<div class="li"><span>자가진화 모델</span><span class="sp"></span><span class="mut">'+esc(c.fable_model||'')+'</span></div>'+
    '<div class="li"><span>점검 모드</span><span class="sp"></span>'+(h.maintenance?'<span class="tag b-off">ON</span>':'<span class="tag b-on">OFF</span>')+'</div>';
}

// 자동 새로고침(현재 탭만) 20초
setInterval(function(){ if(!document.getElementById('dash').classList.contains('hidden')) loadTab(); }, 20000);
if(TK){ jget('/admin/stats').then(function(){ show(); tab('home'); }).catch(function(){ logout(); }); }
</script>
</body></html>"""
