# -*- coding: utf-8 -*-
"""
mobile_ui.py — 폰 조회용 모바일 웹 대시보드 (단일 HTML)
=====================================================
폰 브라우저에서 http://<서버>:8000/m 접속 → 로그인 → 내 자산/수익/포지션/AI신호를 조회.
데이터는 '클라이언트(PC)가 /status/push 로 올린 비민감 상태'를 그대로 보여준다(주문·키 없음).
"""

MOBILE_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>알파봇</title>
<style>
:root{--bg:#0b0e14;--card:#141922;--bd:#232a36;--tx:#e6e9ef;--mut:#8a93a6;--acc:#3b82f6;--g:#22c55e;--r:#ef4444}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font-family:system-ui,'Malgun Gothic',sans-serif;font-size:15px}
.wrap{max-width:520px;margin:0 auto;padding:14px}
h1{font-size:19px;margin:0}
.card{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:14px;margin:10px 0}
.row{display:flex;align-items:center;gap:8px}
.sp{flex:1}.mut{color:var(--mut)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.kpi{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:11px}
.kpi .l{color:var(--mut);font-size:12px}.kpi .v{font-size:17px;font-weight:800;margin-top:3px}
.big{font-size:26px;font-weight:900}
.g{color:var(--g)}.r{color:var(--r)}
.tag{padding:2px 9px;border-radius:20px;font-size:11px;font-weight:800}
.b-buy{background:rgba(34,197,94,.18);color:#4ade80}.b-sell{background:rgba(239,68,68,.18);color:#f87171}
.b-hold{background:rgba(138,147,166,.18);color:#cbd5e1}.b-on{background:rgba(34,197,94,.18);color:#4ade80}.b-off{background:rgba(239,68,68,.18);color:#f87171}
.li{display:flex;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid var(--bd)}
.li:last-child{border-bottom:0}
input{width:100%;background:#0f141c;color:var(--tx);border:1px solid var(--bd);border-radius:10px;padding:11px;font-size:15px;margin:6px 0}
button{width:100%;background:var(--acc);color:#fff;border:0;border-radius:10px;padding:12px;font-size:15px;font-weight:700}
button.ghost{background:#1e2632;border:1px solid var(--bd)}
.sub{font-size:12px;color:var(--mut)}
h2{font-size:13px;color:var(--mut);margin:16px 4px 4px;font-weight:700}
.hidden{display:none}
</style></head><body>

<div id="login" class="wrap" style="margin-top:14vh">
  <div class="card">
    <h1>⚡ 알파봇</h1>
    <p class="sub">내 계정으로 로그인</p>
    <input id="u" placeholder="아이디" autocomplete="username">
    <input id="p" type="password" placeholder="비밀번호" autocomplete="current-password">
    <button onclick="login()">로그인</button>
    <div id="lerr" class="sub" style="color:var(--r);margin-top:8px"></div>
  </div>
</div>

<div id="dash" class="wrap hidden">
  <div class="row">
    <h1>⚡ 알파봇</h1><span id="run" class="tag"></span>
    <div class="sp"></div><span id="upd" class="sub"></span>
    <button class="ghost" style="width:auto;padding:7px 12px;font-size:13px" onclick="logout()">로그아웃</button>
  </div>

  <div class="card">
    <div class="l mut" style="font-size:12px">총자산</div>
    <div id="total" class="big">—</div>
    <div class="row" style="margin-top:6px"><span class="sub">원화 <b id="krw">—</b></span><span class="sp"></span><span class="sub">코인 <b id="coin">—</b> (<span id="cratio">—</span>)</span></div>
  </div>

  <div class="grid2">
    <div class="kpi"><div class="l">오늘 수익</div><div id="today" class="v">—</div></div>
    <div class="kpi"><div class="l">보유 손익</div><div id="pos" class="v">—</div></div>
    <div class="kpi"><div class="l">당일 실현</div><div id="real" class="v">—</div></div>
    <div class="kpi"><div class="l">누적 수익</div><div id="cum" class="v">—</div></div>
  </div>

  <h2>보유 포지션</h2>
  <div class="card" id="poss"><span class="mut sub">—</span></div>

  <h2>AI 신호</h2>
  <div class="card" id="ai"><span class="mut sub">—</span></div>

  <h2>최근 거래</h2>
  <div class="card" id="trd"><span class="mut sub">—</span></div>

  <p class="sub" style="text-align:center;margin:18px 0">공포탐욕 <span id="fng">—</span> · 10초마다 자동 갱신</p>
</div>

<script>
var TK = localStorage.getItem('ab_m_tk') || '';
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
function won(v){v=Number(v||0);return (v>=0?'':'-')+Math.abs(v).toLocaleString('ko-KR',{maximumFractionDigits:0})+'원'}
function sgn(v){v=Number(v||0);return (v>=0?'+':'')+v.toLocaleString('ko-KR',{maximumFractionDigits:0})}
function pct(v){v=Number(v||0);return (v>=0?'+':'')+v.toFixed(2)+'%'}
function cls(v){return Number(v||0)>=0?'g':'r'}
function coinName(t){return String(t||'').replace('KRW-','')}

async function login(){
  var u=document.getElementById('u').value.trim(), p=document.getElementById('p').value;
  var e=document.getElementById('lerr'); e.textContent='';
  try{
    var r=await fetch('/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
    var d=await r.json().catch(function(){return{}});
    if(!r.ok){ e.textContent = r.status===403?'차단된 계정입니다.':'아이디/비밀번호가 틀립니다.'; return; }
    TK=d.token; localStorage.setItem('ab_m_tk',TK); show(); load();
  }catch(err){ e.textContent='서버에 연결할 수 없습니다.'; }
}
function show(){ document.getElementById('login').classList.add('hidden'); document.getElementById('dash').classList.remove('hidden'); }
function logout(){ TK=''; localStorage.removeItem('ab_m_tk'); document.getElementById('dash').classList.add('hidden'); document.getElementById('login').classList.remove('hidden'); }

function setv(id,txt,c){ var el=document.getElementById(id); el.textContent=txt; if(c){el.className=el.className.replace(/ ?[gr]$/,'')+' '+c;} }

async function load(){
  if(!TK) return;
  try{
    var r=await fetch('/status/me',{headers:{'Authorization':'Bearer '+TK}});
    if(r.status===401||r.status===403){ logout(); return; }
    var d=await r.json();
    render(d);
  }catch(e){}
}

function render(d){
  var run=document.getElementById('run');
  run.textContent = d.running?'실행 중':'정지';
  run.className='tag '+(d.running?'b-on':'b-off');
  var s=d.status||{}; var k=s.kpi||{};
  document.getElementById('upd').textContent = s.updated_at? String(s.updated_at).slice(5,16):'';
  if(!s || !s.kpi){ document.getElementById('total').textContent='데이터 없음'; document.getElementById('poss').innerHTML='<span class="mut sub">아직 PC 클라이언트가 상태를 안 올렸어요(클라이언트 실행 중인지 확인).</span>'; return; }

  document.getElementById('total').textContent = won(k.total_asset);
  document.getElementById('krw').textContent = won(k.krw);
  document.getElementById('coin').textContent = won(k.coin_value);
  document.getElementById('cratio').textContent = pct(k.coin_ratio).replace('+','');
  setv('today', sgn(k.today_pnl)+' ('+pct(k.today_rate)+')', cls(k.today_pnl));
  setv('pos', sgn(k.pos_pnl)+' ('+pct(k.pos_pnl_rate)+')', cls(k.pos_pnl));
  setv('real', sgn(k.realized_today)+' ('+pct(k.realized_today_rate)+')', cls(k.realized_today));
  setv('cum', sgn(k.cum_pnl)+' ('+pct(k.cum_rate)+')', cls(k.cum_pnl));

  var pos=s.positions||[];
  document.getElementById('poss').innerHTML = pos.length? pos.map(function(p){
    var pn=(Number(p.avg)>0);
    return '<div class="li"><b>'+esc(coinName(p.ticker))+'</b> <span class="sub">'+won(p.value)+'</span><span class="sp"></span><span class="'+cls(p.pnl_krw)+'">'+(pn?(sgn(p.pnl_krw)+' ('+pct(p.pnl)+')'):'—')+'</span></div>';
  }).join('') : '<span class="mut sub">보유 코인이 없습니다.</span>';

  var ai=s.analysis||[];
  document.getElementById('ai').innerHTML = ai.length? ai.map(function(a){
    var dec=a.decision||'HOLD'; var cl=dec==='BUY'?'b-buy':(dec==='SELL'?'b-sell':'b-hold');
    return '<div class="li"><b>'+esc(coinName(a.ticker))+'</b><span class="sp"></span><span class="tag '+cl+'">'+esc(dec)+'</span></div>'+
           '<div class="sub" style="margin:-4px 0 6px 2px">'+esc(a.reasoning||'')+'</div>';
  }).join('') : '<span class="mut sub">아직 신호가 없습니다.</span>';

  var trd=s.trades||[];
  document.getElementById('trd').innerHTML = trd.length? trd.slice(0,8).map(function(x){
    var buy=x.action==='BUY'; var pn=(x.pnl!=null);
    return '<div class="li"><b class="'+(buy?'g':'r')+'">'+(buy?'매수':'매도')+'</b> '+esc(coinName(x.ticker))+' <span class="sub">'+String(x.ts||'').slice(5,16)+'</span><span class="sp"></span><span class="'+(pn?cls(x.pnl):'mut')+'">'+(pn?pct(x.pnl):won(x.amount))+'</span></div>';
  }).join('') : '<span class="mut sub">거래 내역이 없습니다.</span>';

  var fng=s.fng||{}; document.getElementById('fng').textContent = (fng.value!=null)?(fng.value+' ('+(fng.classification||'')+')'):'—';
}

setInterval(function(){ if(!document.getElementById('dash').classList.contains('hidden')) load(); }, 10000);
if(TK){ show(); load(); }
</script>
</body></html>"""
