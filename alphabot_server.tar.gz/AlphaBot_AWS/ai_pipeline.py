# -*- coding: utf-8 -*-
"""
ai_pipeline.py — 2단계 AI 파이프라인 (DeepSeek 1차 요약 → Claude Sonnet 최종결정)
=====================================================
흐름:
  1) market_data.collect()  — 업비트 공개데이터(다봉 지표·호가·BTC맥락·공포탐욕) 수집
  2) DeepSeek(1차)          — 위 원자료를 '기술적 팩트 JSON'으로 압축(판단은 안 함)
  3) Claude Sonnet(최종)     — 팩트 + 내 최근판단(휩쏘방지) 을 보고 BUY/SELL/HOLD + next_check_in
                              + 초압축 reason 키워드 결정. 시스템 프롬프트는 DB의 '활성 버전'(Fable이 진화).
  4) 결과를 기존 클라이언트 스키마로 변환 + decision_log에 기록(관리자 모니터링 + Fable 학습).

[공유 캐시] 여러 사용자가 같은 코인을 요청하면 코인별로 '한 번만' 분석해 공유(중복 AI 호출/과금 방지).
[동시성] 캐시 만료 순간 요청이 몰려도 in-flight 표시로 한 번만 호출하고 나머지는 그 결과를 기다림.
[실패 안전] AI 실패 시 그 코인은 '방어적 HOLD'로 채우고 짧게 재시도(전체가 죽지 않게).
"""
import re
import json
import time
import threading

import requests

import db
import market_data
from settings import settings

_TF_LABEL = {"minutes/15": "15m", "minutes/60": "1h", "minutes/240": "4h", "days": "1d"}

# ── 공유 캐시 + in-flight ────────────────────────────────────────────
_cache = {}      # ticker -> (expire_epoch, signal_dict)
_inflight = {}   # ticker -> threading.Event
_fail_streak = {}
_lock = threading.Lock()
INFLIGHT_WAIT = 100


# ── 초압축 reason 키워드 → 한국어(클라이언트 로그에 읽기 좋게) ────────
KEYWORD_KO = {
    "RSI_LOW": "RSI 과매도", "RSI_HIGH": "RSI 과매수", "RSI_UP": "RSI 반등", "RSI_DOWN": "RSI 하락",
    "MACD_UP": "MACD 상승전환", "MACD_DOWN": "MACD 하락전환", "GOLDEN_CROSS": "골든크로스",
    "DEAD_CROSS": "데드크로스", "BB_LOW": "볼밴 하단 지지", "BB_UP": "볼밴 상단 저항",
    "VOL_UP": "거래량 급증", "VOL_DOWN": "거래량 위축", "ORDERBOOK_IMBALANCE": "매수벽 우위",
    "ORDERBOOK_SELL": "매도벽 우위", "TREND_UP": "상승추세", "TREND_DOWN": "하락추세",
    "SUPPORT": "지지선 근접", "RESISTANCE": "저항선 근접", "BTC_WEAK": "BTC 약세", "BTC_STRONG": "BTC 강세",
    "PULLBACK": "눌림목", "REBOUND_CONFIRMED": "반등 확인", "WHIPSAW_RISK": "휩쏘 우려",
    "MIXED": "신호 혼재", "LOW_CONFIDENCE": "근거 부족",
}


def _reason_ko(code: str) -> str:
    if not code:
        return "근거 미상"
    parts = [p.strip() for p in re.split(r"[+,/ ]+", code) if p.strip()]
    return " · ".join(KEYWORD_KO.get(p.upper(), p) for p in parts)


# ── 견고한 JSON 추출(모델 응답이 지저분해도) ─────────────────────────
def _clean(text: str) -> str:
    t = text or ""
    t = re.sub(r"<think>.*?</think>", "", t, flags=re.DOTALL)
    if "</think>" in t:
        t = t.split("</think>")[-1]
    t = re.sub(r"```(?:json)?", "", t).strip().strip("`")
    return t


def _extract_json(text: str):
    text = _clean(text)
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{[\s\S]*\}", text or "")
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return None
    return None


# ── LLM 호출 ─────────────────────────────────────────────────────────
def _call_deepseek(messages: list) -> tuple[str, str]:
    """DeepSeek(OpenAI 호환). 반환 (content, err)."""
    key = settings.DEEPSEEK_API_KEY
    if not key:
        return "", "DEEPSEEK_API_KEY 미설정"
    try:
        r = requests.post(settings.DEEPSEEK_BASE_URL,
                          headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                          json={"model": settings.DEEPSEEK_MODEL, "messages": messages, "temperature": 0.2},
                          timeout=settings.AI_TIMEOUT_SEC)
        if r.status_code != 200:
            return "", f"HTTP {r.status_code}: {r.text[:150]}"
        return r.json()["choices"][0]["message"]["content"], ""
    except requests.exceptions.Timeout:
        return "", "DeepSeek 타임아웃"
    except Exception as e:
        return "", f"DeepSeek 예외: {e}"


def _call_claude(system: str, user_content: str, model: str, max_tokens: int = 1500) -> tuple[str, str]:
    """Claude 네이티브 Messages API. 반환 (content_text, err).
    [비용 레버 2] system 프롬프트에 prompt caching(cache_control)을 걸어, 매 호출마다 반복되는
    시스템 프롬프트 입력토큰을 캐시에서 재사용(캐시히트는 정상단가의 ~10%)한다. 프롬프트가
    캐시 최소길이보다 짧으면 그냥 캐시가 안 될 뿐 오류는 없다(무해). Fable이 프롬프트를 키울수록
    절감폭이 커진다."""
    key = settings.ANTHROPIC_API_KEY
    if not key:
        return "", "ANTHROPIC_API_KEY 미설정"
    try:
        r = requests.post(settings.ANTHROPIC_BASE_URL,
                          headers={"x-api-key": key, "anthropic-version": settings.ANTHROPIC_VERSION,
                                   "content-type": "application/json"},
                          json={"model": model, "max_tokens": max_tokens,
                                "system": [{"type": "text", "text": system,
                                            "cache_control": {"type": "ephemeral"}}],
                                "messages": [{"role": "user", "content": user_content}]},
                          timeout=settings.AI_TIMEOUT_SEC)
        if r.status_code != 200:
            return "", f"HTTP {r.status_code}: {r.text[:150]}"
        data = r.json()
        parts = data.get("content", [])
        text = "".join(p.get("text", "") for p in parts if isinstance(p, dict))
        return text, ""
    except requests.exceptions.Timeout:
        return "", "Claude 타임아웃"
    except Exception as e:
        return "", f"Claude 예외: {e}"


# ── 1차: DeepSeek 요약 ───────────────────────────────────────────────
def _deepseek_summarize(snapshot: dict, coins: list) -> tuple[dict, str, int]:
    """원자료 → 코인별 '기술적 팩트 JSON'. 판단(BUY/SELL)은 하지 않는다."""
    sys_msg = ("너는 시장데이터 압축기다. 주어진 코인별 다봉 지표/호가/BTC맥락을 읽고, 각 코인의 "
               "'기술적 사실'만 간결한 JSON으로 요약하라. 매매결정(BUY/SELL/HOLD)은 절대 하지 마라. "
               "각 코인에 대해 추세방향(1d/4h/1h/15m), 모멘텀(RSI·MACD 방향), 거래량 신뢰도(vol_ratio), "
               "지지/저항 위치, 호가 불균형을 짧게 담아라. "
               "출력은 {\"KRW-BTC\": {..간결팩트..}, ...} 형태의 JSON 하나로만.")
    user = json.dumps({"coins_requested": coins, "data": snapshot}, ensure_ascii=False)
    t0 = time.time()
    content, err = _call_deepseek([{"role": "system", "content": sys_msg},
                                   {"role": "user", "content": user}])
    ms = int((time.time() - t0) * 1000)
    if err:
        return {}, err, ms
    parsed = _extract_json(content)
    return (parsed if isinstance(parsed, dict) else {}), ("" if isinstance(parsed, dict) else "요약 JSON 파싱 실패"), ms


# ── 2차: Claude Sonnet 최종결정 ──────────────────────────────────────
def _recent_for_prompt(ticker: str, cur_price: float | None) -> list:
    out = []
    for h in db.recent_decisions_for(ticker):
        item = {"ago_min": round((time.time() - float(h["ts_epoch"])) / 60), "decision": h["decision"]}
        if cur_price and h.get("price"):
            try:
                item["price_change_pct_since"] = round((cur_price / float(h["price"]) - 1) * 100, 2)
            except Exception:
                pass
        out.append(item)
    return out


def _decide(facts: dict, snapshot: dict, coins: list, model: str) -> tuple[dict, str, int]:
    """주어진 모델로 최종 매매결정. 평상시엔 값싼 모델(Haiku), 실제 매매건만 Sonnet으로 재확인."""
    ap = db.active_prompt()
    system = ap["system_prompt"] if ap else "너는 신중한 단기 트레이더다. BUY/SELL/HOLD를 JSON으로 답하라."
    # 코인별 현재가(15m close) + 최근판단 첨부
    recent = {}
    for c in coins:
        px = ((snapshot.get("coins", {}).get(c, {}).get("15m", {}) or {}).get("close"))
        recent[c] = _recent_for_prompt(c, px)
    payload = {
        "market_sentiment": snapshot.get("market_sentiment"),
        "market_context": snapshot.get("market_context"),
        "facts": facts,
        "recent_decisions": recent,
        "output_spec": {"각 코인": {"decision": "BUY|SELL|HOLD", "next_check_in": "초(정수)",
                                   "reason": "초압축 키워드(예: RSI_LOW+VOL_UP+BB_LOW)"}},
        "coins": coins,
    }
    user = ("아래 팩트로 각 코인의 매매를 결정하라. 반드시 "
            "{\"KRW-BTC\": {\"decision\":\"HOLD\",\"next_check_in\":900,\"reason\":\"MIXED\"}, ...} "
            "형태의 JSON 하나로만 답하라.\n" + json.dumps(payload, ensure_ascii=False))
    t0 = time.time()
    content, err = _call_claude(system, user, model, max_tokens=1500)
    ms = int((time.time() - t0) * 1000)
    if err:
        return {}, err, ms
    parsed = _extract_json(content)
    return (parsed if isinstance(parsed, dict) else {}), ("" if isinstance(parsed, dict) else "결정 JSON 파싱 실패"), ms


# ── 신호등 보조지표(클라이언트 UI 유지용) ────────────────────────────
def _default_ind():
    return {"volume": {"state": "gray", "label": "거래량", "tooltip": "데이터 부족"},
            "rotation": {"state": "gray", "label": "순환매", "tooltip": "데이터 부족"},
            "onchain": {"state": "gray", "label": "온체인", "tooltip": "연동 예정"}}


def _traffic(snapshot: dict, ticker: str):
    ind = _default_ind()
    try:
        vr = (snapshot.get("coins", {}).get(ticker, {}).get("1h", {}) or {}).get("vol_ratio")
        if vr is not None:
            if vr >= 1.8:
                ind["volume"] = {"state": "green", "label": "거래량", "tooltip": f"평균 대비 {vr:.1f}배 급증"}
            elif vr <= 0.5:
                ind["volume"] = {"state": "red", "label": "거래량", "tooltip": f"평균의 {vr:.1f}배 위축"}
            else:
                ind["volume"] = {"state": "gray", "label": "거래량", "tooltip": f"평균 대비 {vr:.1f}배"}
        mc = snapshot.get("market_context") or {}
        btc_rsi = mc.get("BTC_1d_rsi")
        if btc_rsi is not None and ticker != "KRW-BTC":
            if btc_rsi >= 55:
                ind["rotation"] = {"state": "green", "label": "순환매", "tooltip": f"BTC 강세(1d RSI {btc_rsi})"}
            elif btc_rsi <= 40:
                ind["rotation"] = {"state": "red", "label": "순환매", "tooltip": f"BTC 약세(1d RSI {btc_rsi})"}
    except Exception:
        pass
    return ind


def _clamp_ttl(nci) -> int:
    try:
        v = int(nci)
    except Exception:
        v = settings.SIGNAL_TTL_SEC
    return max(settings.SIGNAL_MIN_TTL_SEC, min(v, settings.SIGNAL_TTL_SEC))


# ── 공개 진입점 ──────────────────────────────────────────────────────
def get_signals(coins: list) -> list:
    """요청 코인들의 최신 신호(공유 캐시). 반환은 기존 클라이언트 스키마 리스트."""
    now = time.time()
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    coins = [c for c in dict.fromkeys(coins) if c]

    with _lock:
        need, wait_for = [], []
        for c in coins:
            hit = _cache.get(c)
            if hit and now < hit[0]:
                continue
            ev = _inflight.get(c)
            if ev is not None:
                wait_for.append(ev); continue
            need.append(c); _inflight[c] = threading.Event()

    for ev in wait_for:
        ev.wait(INFLIGHT_WAIT)

    if need:
        try:
            _analyze(need, ts)
        finally:
            with _lock:
                for c in need:
                    ev = _inflight.pop(c, None)
                    if ev is not None:
                        ev.set()

    with _lock:
        return [_cache[c][1] for c in coins if c in _cache]


# AI 키 형식 흔들림 방어(btc/KRW_BTC → KRW-BTC)
def _norm(d):
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            fixed = str(k).upper().replace("_", "-")
            if not fixed.startswith("KRW-"):
                fixed = "KRW-" + fixed
            out[fixed] = v
    return out


def _analyze(need: list, ts: str):
    snapshot = market_data.collect(need)
    facts, ds_err, ds_ms = _deepseek_summarize(snapshot, need)
    decisions, sn_err, sn_ms = ({}, "", 0)
    if not ds_err:
        # [비용 레버 3] 1차: 값싼 모델(Haiku)로 전 코인 판단(대부분 HOLD → 저렴).
        decisions, sn_err, base_ms = _decide(facts, snapshot, need, settings.DECISION_MODEL)
        decisions = _norm(decisions)
        sn_ms = base_ms
        # 2차: 실제 매매(BUY/SELL)로 나온 코인만 Sonnet으로 재확인(고스테이크만 정확한 모델).
        #      Sonnet이 더 보수적으로 보고 HOLD로 내려도 그걸 최종으로 채택(품질 안전망).
        if settings.ESCALATE_ACTIONABLE and not sn_err:
            actionable = [c for c in need
                          if isinstance(decisions.get(c), dict)
                          and decisions[c].get("decision") in ("BUY", "SELL")]
            if actionable:
                esc, esc_err, esc_ms = _decide(facts, snapshot, actionable, settings.SONNET_MODEL)
                sn_ms = base_ms + esc_ms
                if not esc_err:
                    esc = _norm(esc)
                    for c in actionable:
                        if isinstance(esc.get(c), dict) and esc[c].get("decision") in ("BUY", "SELL", "HOLD"):
                            decisions[c] = esc[c]   # Sonnet 재확인 결과가 최종

    for c in need:
        item = decisions.get(c) if isinstance(decisions, dict) else None
        px = ((snapshot.get("coins", {}).get(c, {}).get("15m", {}) or {}).get("close"))
        if isinstance(item, dict) and item.get("decision") in ("BUY", "SELL", "HOLD"):
            dec = item["decision"]
            code = str(item.get("reason", "") or "")
            nci = _clamp_ttl(item.get("next_check_in"))
            sig = {"ticker": c, "decision": dec, "reasoning": _reason_ko(code),
                   "reason_code": code, "ts": ts, "ttl_sec": nci, "next_check_in": nci,
                   "indicators": _traffic(snapshot, c)}
            with _lock:
                _fail_streak[c] = 0
                _cache[c] = (time.time() + nci, sig)
            db.log_decision(c, dec, code, next_check_in=nci, price=px,
                            features=facts.get(c) if isinstance(facts, dict) else None,
                            deepseek_ms=ds_ms, sonnet_ms=sn_ms, ok=True)
        else:
            err = ds_err or sn_err or "AI 응답 누락"
            nci = settings.SIGNAL_FAIL_RETRY_SEC
            sig = {"ticker": c, "decision": "HOLD", "reasoning": f"AI 응답 실패({err}) — 방어적 HOLD",
                   "reason_code": "LOW_CONFIDENCE", "ts": ts, "ttl_sec": nci, "next_check_in": nci,
                   "indicators": _traffic(snapshot, c)}
            with _lock:
                streak = min(_fail_streak.get(c, 0) + 1, 20)
                _fail_streak[c] = streak
                retry = min(settings.SIGNAL_FAIL_RETRY_SEC * (2 ** (streak - 1)), settings.SIGNAL_TTL_SEC)
                sig["ttl_sec"] = retry; sig["next_check_in"] = retry
                _cache[c] = (time.time() + retry, sig)
            db.log_decision(c, "HOLD", "LOW_CONFIDENCE", next_check_in=nci, price=px,
                            deepseek_ms=ds_ms, sonnet_ms=sn_ms, ok=False)
