# -*- coding: utf-8 -*-
"""
market_data.py — 업비트 '공개데이터' 수집기 (AWS 서버 전담)
=====================================================
[보안] 사용자의 업비트 API Key를 절대 다루지 않는다. 여기서 부르는 건 전부 '공개' 엔드포인트
       (시세/호가/체결/캔들)뿐이다. 주문·잔고 같은 개인 API는 오직 클라이언트(사용자 PC)만 한다.
[성능] '빠르고 오류 적게'가 목표:
   · 커넥션 풀 + 자동 재시도(429/5xx) 로 순간 실패를 흡수.
   · 배치 조회(시세/호가는 여러 마켓을 한 번에) 로 요청 수를 코인 수와 무관하게 줄임.
   · 레이트리밋(공개 API 초당 한도) 을 스스로 지켜서 IP 차단을 피함.
   · 캔들/지표는 짧은 TTL 캐시 로 매 주기 재계산·재호출 부담을 낮춤.
반환 스키마는 기존 서버(ai_signals._collect)와 동일한 모양을 유지해서, 이후 파이프라인/클라이언트가
그대로 이어받을 수 있게 한다.
"""
import time
import threading
from collections import deque

import requests
from requests.adapters import HTTPAdapter
try:
    from urllib3.util.retry import Retry
except Exception:   # 아주 오래된 urllib3 방어
    Retry = None

import pandas as pd
import numpy as np

from settings import settings

UPBIT = settings.UPBIT_BASE.rstrip("/")


# ── 공용 세션(커넥션 재사용 + 자동 재시도) ───────────────────────────
def _make_session() -> requests.Session:
    s = requests.Session()
    if Retry is not None:
        retry = Retry(
            total=2, connect=2, read=2, backoff_factor=0.3,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET"]),
            raise_on_status=False,
        )
        ad = HTTPAdapter(max_retries=retry, pool_connections=20, pool_maxsize=20)
        s.mount("https://", ad)
        s.mount("http://", ad)
    s.headers.update({"Accept": "application/json", "User-Agent": "AlphaBot/1.0"})
    return s


_session = _make_session()


# ── 레이트리밋(공개 API 초당 한도 준수) ──────────────────────────────
class _RateLimiter:
    """직전 1초 안의 호출 수가 한도를 넘으면 잠깐 쉬어서 429(IP 차단)를 예방."""
    def __init__(self, max_per_sec: int):
        self.max = max(1, int(max_per_sec))
        self._calls = deque()
        self._lock = threading.Lock()

    def wait(self):
        with self._lock:
            now = time.monotonic()
            while self._calls and now - self._calls[0] > 1.0:
                self._calls.popleft()
            if len(self._calls) >= self.max:
                sleep_for = 1.0 - (now - self._calls[0]) + 0.02
                if sleep_for > 0:
                    time.sleep(sleep_for)
                now = time.monotonic()
                while self._calls and now - self._calls[0] > 1.0:
                    self._calls.popleft()
            self._calls.append(time.monotonic())


_limiter = _RateLimiter(settings.UPBIT_MAX_REQ_PER_SEC)


def _get(path: str, params: dict | None = None, timeout: float = 8.0):
    """업비트 공개 GET 1건(레이트리밋 준수 + 재시도는 세션 어댑터가 담당)."""
    _limiter.wait()
    r = _session.get(f"{UPBIT}{path}", params=params, timeout=timeout)
    r.raise_for_status()
    return r.json()


# ── 짧은 TTL 캐시(캔들/지표 과호출 방지) ─────────────────────────────
_cache: dict = {}
_cache_lock = threading.Lock()


def _cached(key: str, ttl: float, producer):
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < ttl:
            return hit[1]
    val = producer()   # 캐시 밖에서 계산(락을 오래 잡지 않음)
    with _cache_lock:
        _cache[key] = (now, val)
    return val


# ── 원자재 데이터 조회 ───────────────────────────────────────────────
def get_markets_krw() -> list:
    """원화마켓 전체 티커 목록(KRW-...)."""
    def prod():
        data = _get("/market/all", {"isDetails": "false"})
        return [d["market"] for d in data if str(d.get("market", "")).startswith("KRW-")]
    return _cached("markets_krw", 3600, prod)   # 하루 단위로도 거의 안 바뀜 → 1시간 캐시


def get_prices(markets: list) -> dict:
    """여러 마켓 현재가를 '한 번의 요청'으로. 반환 {market: trade_price}."""
    markets = [m for m in markets if m]
    if not markets:
        return {}
    try:
        data = _get("/ticker", {"markets": ",".join(markets)})
        return {d["market"]: float(d["trade_price"]) for d in data if d.get("trade_price") is not None}
    except Exception:
        return {}


def get_orderbooks(markets: list) -> dict:
    """여러 마켓 호가를 '한 번의 요청'으로. 반환 {market: {bid_size, ask_size, imbalance}}."""
    markets = [m for m in markets if m]
    if not markets:
        return {}
    out = {}
    try:
        data = _get("/orderbook", {"markets": ",".join(markets)})
        for ob in data:
            mk = ob.get("market")
            units = (ob.get("orderbook_units") or [])[:5]   # 상위 5호가만
            bid = sum(float(u.get("bid_size", 0) or 0) for u in units)
            ask = sum(float(u.get("ask_size", 0) or 0) for u in units)
            tot = bid + ask
            out[mk] = {
                "bid_size": round(bid, 2),
                "ask_size": round(ask, 2),
                # 매수벽/매도벽 불균형(-1~+1, +면 매수 우위). ※ 세력이 만들었다 지울 수 있어 보조지표로만.
                "imbalance": round((bid - ask) / tot, 3) if tot > 0 else 0.0,
            }
    except Exception:
        pass
    return out


def _ohlcv(market: str, unit: str, count: int = 200) -> pd.DataFrame:
    """캔들 조회 → 오래된 순 DataFrame. unit: 'days' 또는 'minutes/{1,3,5,10,15,30,60,240}'."""
    def prod():
        if unit == "days":
            raw = _get("/candles/days", {"market": market, "count": count})
        else:
            u = unit.split("/")[1]
            raw = _get(f"/candles/minutes/{u}", {"market": market, "count": count})
        raw = list(reversed(raw or []))   # 업비트는 최신→과거 순 → 과거→최신으로 뒤집음
        if not raw:
            return pd.DataFrame()
        df = pd.DataFrame(raw)
        rename = {
            "opening_price": "open", "high_price": "high", "low_price": "low",
            "trade_price": "close", "candle_acc_trade_volume": "volume",
        }
        df = df.rename(columns=rename)
        for c in ("open", "high", "low", "close", "volume"):
            if c in df:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        return df
    return _cached(f"ohlcv:{market}:{unit}:{count}", settings.OHLCV_CACHE_SEC, prod)


# ── 지표 계산(순수 pandas/numpy — 외부 지표 라이브러리 의존 없음) ───────
def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Wilder RSI. ewm(alpha=1/period)로 와일더 스무딩을 재현."""
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    rsi = 100.0 - (100.0 / (1.0 + rs))
    # 손실이 0이면(무한 상승) RSI=100
    rsi = rsi.where(avg_loss != 0, 100.0)
    return rsi


def _macd_hist(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> pd.Series:
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    sig = macd.ewm(span=signal, adjust=False).mean()
    return macd - sig   # 히스토그램(=MACD - 시그널)


def _bollinger(close: pd.Series, period: int = 20, mult: float = 2.0):
    ma = close.rolling(period).mean()
    sd = close.rolling(period).std(ddof=0)
    return ma + mult * sd, ma - mult * sd


def _last3(series: pd.Series) -> list:
    try:
        return [round(float(x), 4) for x in series.dropna().tail(3).tolist()]
    except Exception:
        return []


def indicators(market: str, unit: str) -> dict:
    """한 봉단위(unit)의 지표 묶음. 기존 서버와 같은 키 구성(방향값·추세·거래량비율 포함)."""
    out: dict = {}
    try:
        df = _ohlcv(market, unit, 200)
        if df is None or len(df) < 30 or "close" not in df:
            return out
        close = df["close"]
        rsi = _rsi(close)
        hist = _macd_hist(close)
        bb_high, bb_low = _bollinger(close)

        out["rsi"] = round(float(rsi.iloc[-1]), 2)
        out["rsi_prev"] = round(float(rsi.iloc[-2]), 2)
        out["rsi_trend"] = _last3(rsi)
        out["macd_hist"] = round(float(hist.iloc[-1]), 4)
        out["macd_hist_prev"] = round(float(hist.iloc[-2]), 4)
        out["macd_hist_trend"] = _last3(hist)
        out["bb_high"] = round(float(bb_high.iloc[-1]), 2)
        out["bb_low"] = round(float(bb_low.iloc[-1]), 2)
        out["close"] = round(float(close.iloc[-1]), 2)
        out["close_trend"] = _last3(close)
        try:
            out["change_3bar_pct"] = round((float(close.iloc[-1]) / float(close.iloc[-4]) - 1) * 100, 2)
        except Exception:
            pass
        # 거래량 신뢰도: 최근 봉 거래량 / 직전 20봉 평균 (1.5+ 실림, 0.5- 위축)
        try:
            vol = df["volume"]
            vavg = float(vol.iloc[-21:-1].mean())
            if vavg > 0:
                out["vol_ratio"] = round(float(vol.iloc[-1]) / vavg, 2)
        except Exception:
            pass
        # 최근 10봉 스윙 고점/저점(지지·저항 감각)
        try:
            out["recent_high"] = round(float(df["high"].tail(10).max()), 2)
            out["recent_low"] = round(float(df["low"].tail(10).min()), 2)
        except Exception:
            pass
    except Exception:
        pass
    return out


def fear_greed() -> int | None:
    """공포탐욕지수(0~100). 업비트 외부(alternative.me) — 보조지표."""
    def prod():
        try:
            r = _session.get("https://api.alternative.me/fng/?limit=1", timeout=8)
            if r.status_code == 200:
                return int(r.json()["data"][0]["value"])
        except Exception:
            pass
        return None
    return _cached("fng", 1800, prod)   # 30분 캐시


# ── 종합 수집(딥시크에 넘길 시장 스냅샷) ─────────────────────────────
def collect(markets: list, timeframes: tuple = ("minutes/15", "minutes/60", "minutes/240", "days")) -> dict:
    """요청 코인들의 다봉 지표 + 호가 + BTC 맥락 + 공포탐욕지수를 한 덩어리로.
       반환 스키마는 기존 ai_signals._collect와 동일(15m/1h/4h/1d/orderbook)."""
    markets = [m for m in dict.fromkeys(markets) if m]
    data = {"collected_at": int(time.time()), "market_sentiment": fear_greed(), "coins": {}}

    # BTC 맥락(알트는 대체로 BTC를 따라감)
    try:
        b4 = indicators("KRW-BTC", "minutes/240")
        b1d = indicators("KRW-BTC", "days")
        data["market_context"] = {
            "BTC_4h_rsi": b4.get("rsi"), "BTC_4h_rsi_prev": b4.get("rsi_prev"),
            "BTC_1d_rsi": b1d.get("rsi"), "BTC_1d_close_trend": b1d.get("close_trend"),
            "BTC_1d_change_3bar_pct": b1d.get("change_3bar_pct"),
            "note": "BTC가 하락 추세면 알트 신규매수는 특히 보수적으로. BTC가 강하면 알트 반등도 신뢰↑.",
        }
    except Exception:
        pass

    obs = get_orderbooks(markets)   # 호가는 한 번에 배치 조회
    label = {"minutes/15": "15m", "minutes/60": "1h", "minutes/240": "4h", "days": "1d"}
    for m in markets:
        entry = {label.get(tf, tf): indicators(m, tf) for tf in timeframes}
        entry["orderbook"] = obs.get(m, {})
        data["coins"][m] = entry
    return data
