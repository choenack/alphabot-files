# -*- coding: utf-8 -*-
"""
admin_ui.py — 관리자 웹 대시보드 (단일 HTML 페이지)
=====================================================
브라우저에서 http://<서버>:8000/admin 접속 → 관리자 로그인 → 클릭으로 관리:
  · 회원수/구독/판단로그 통계, 서버 점검 스위치, 구독 부여, 결제 승인,
  · 회원 목록/검색, AI 가동로그, Fable 프롬프트 진화 이력, Fable 수동 실행.
JWT 토큰은 브라우저 localStorage에 저장(새로고침해도 로그인 유지).
"""

ADMIN_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AlphaBot 관리자</title>
<style>
:root{--bg:#0b0e14;--card:#141922;--bd:#232a36;--tx:#e6e9ef;--mut:#8a93a6;--acc:#3b82f6;--g:#16a34a;--r:#ef4444;--y:#d97706}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font-family:system-ui,'Malgun Gothic',sans-serif;font-size:14px}
.wrap{max-width:1100px;margin:0 auto;padding:16px}
h1{font-size:20px;margin:0} h2{font-size:15px;color:var(--mut);margin:22px 0 8px;font-weight:600}
.card{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:14px}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.kpi{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:12px}
.kpi .l{color:var(--mut);font-size:12px} .kpi .v{font-size:22px;font-weight:800;margin-top:4px}
button{background:var(--acc);color:#fff;border:0;border-radius:8px;padding:8px 12px;cursor:pointer;font-size:13px;font-weight:600}
button.ghost{background:#1e2632;color:var(--tx);border:1px solid var(--bd)}
button.g{background:var(--g)} button.r{background:var(--r)} button:disabled{opacity:.5;cursor:default}
input,select{background:#0f141c;color:var(--tx);border:1px solid var(--bd);border-radius:8px;padding:8px;font-size:13px}
table{width:100%;border-collapse:collapse;font-size:13px} th,td{text-align:left;padding:7px 8px;border-bottom:1px solid var(--bd)}
th{color:var(--mut);font-weight:600} .tag{padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700}
.b-buy{background:rgba(22,163,74,.18);color:#4ade80} .b-sell{background:rgba(239,68,68,.18);color:#f87171}
.b-hold{background:rgba(138,147,166,.18);color:#cbd5e1} .b-on{background:rgba(22,163,74,.18);color:#4ade80}
.b-off{background:rgba(239,68,68,.18);color:#f87171}
#login{max-width:340px;margin:12vh auto} #login input{width:100%;margin:6px 0}
.mut{color:var(--mut)} .sp{flex:1} .hidden{display:none}
.msg{padding:8px 12px;border-radius:8px;background:#1e2632;border:1px solid var(--bd);margin:8px 0;font-size:13px}
</style></head><body>

<div id="login" class="card">
  <h1>🛡️ AlphaBot 관리자</h1>
  <p class="mut" style="font-size:12px">관리자 계정으로 로그인하세요.</p>
  <input id="u" placeholder="아이디" autocomplete="username">
  <input id="p" type="password" placeholder="비밀번호" autocomplete="current-password">
  <button onclick="login()" style="width:100%;margin-top:6px">로그인</button>
  <div id="lerr" class="mut" style="color:var(--r);margin-top:8px;font-size:12px"></div>
</div>

<div id="dash" class="wrap hidden">
  <div class="row"><h1>🛡️ AlphaBot 관리자</h1><span class="mut" id="who"></span><div class="sp"></div>
    <button class="ghost" onclick="loadAll()">↻ 새로고침</button><button class="ghost" onclick="logout()">로그아웃</button></div>

  <h2>현황</h2>
  <div class="grid" id="kpis"></div>

  <h2>서버 제어</h2>
  <div class="card row">
    <span>서버 점검 모드:</span><span id="mnt"></span>
    <button id="mbtn" onclick="toggleMnt()">전환</button>
    <span class="mut" style="font-size:12px">(켜면 신호 엔드포인트 일시중지 — 클라는 손절감시만 유지)</span>
    <div class="sp"></div>
    <button class="ghost" onclick="runFable()">🧬 Fable 자가진화 지금 실행</button>
  </div>

  <h2>구독 부여</h2>
  <div class="card row">
    <input id="su" placeholder="아이디">
    <select id="st"><option value="AUTO">AUTO(자동매매)</option><option value="DATA_ONLY">DATA_ONLY(신호만)</option></select>
    <input id="sd" type="number" value="30" style="width:80px"> <span class="mut">일</span>
    <button class="g" onclick="subUser()">부여/연장</button>
    <span id="smsg" class="mut" style="font-size:12px"></span>
  </div>

  <h2>대기중 결제신청</h2>
  <div class="card"><table id="pend"><thead><tr><th>ID</th><th>아이디</th><th>등급</th><th>금액</th><th>신청시각</th><th>승인</th></tr></thead><tbody></tbody></table></div>

  <h2>회원 <input id="q" placeholder="아이디 검색" oninput="loadUsers()" style="margin-left:8px"></h2>
  <div class="card" style="overflow:auto;max-height:340px"><table id="users"><thead><tr><th>ID</th><th>아이디</th><th>실명</th><th>등급</th><th>구독</th><th>만료일</th><th>상태</th></tr></thead><tbody></tbody></table></div>

  <h2>AI 가동 로그 (최근 판단)</h2>
  <div class="card" style="overflow:auto;max-height:360px"><table id="logs"><thead><tr><th>시각</th><th>코인</th><th>판단</th><th>근거</th><th>주기</th><th>DS/SN(ms)</th></tr></thead><tbody></tbody></table></div>

  <h2>Fable 프롬프트 진화 이력</h2>
  <div class="card" style="overflow:auto;max-height:300px"><table id="prompts"><thead><tr><th>버전</th><th>작성</th><th>요지</th><th>표본</th><th>활성</th><th>생성시각</th></tr></thead><tbody></tbody></table></div>

  <p class="mut" style="text-align:center;margin:24px 0;font-size:12px">AlphaBot AWS 서버 · 관리자 대시보드</p>
</div>

<script>
var TK = localStorage.getItem('ab_admin_tk') || '';
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
async function api(path, opts){
  opts = opts || {}; opts.headers = Object.assign({'Authorization':'Bearer '+TK}, opts.headers||{});
  var r = await fetch(path, opts);
  if(r.status===401||r.status===403){ if(document.getElementById('dash').classList.contains('hidden')){} else { logout(); } throw new Error('auth'); }
  return r;
}
async function login(){
  var u=document.getElementById('u').value.trim(), p=document.getElementById('p').value;
  var e=document.getElementById('lerr'); e.textContent='';
  try{
    var r=await fetch('/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
    var d=await r.json().catch(function(){return{}});
    if(!r.ok){ e.textContent = r.status===403?'차단된 계정입니다.':'아이디/비밀번호가 틀립니다.'; return; }
    if(d.role!=='admin'){ e.textContent='관리자 계정이 아닙니다.'; return; }
    TK=d.token; localStorage.setItem('ab_admin_tk',TK);
    document.getElementById('who').textContent='· '+esc(d.username);
    show(); loadAll();
  }catch(err){ e.textContent='서버에 연결할 수 없습니다.'; }
}
function show(){ document.getElementById('login').classList.add('hidden'); document.getElementById('dash').classList.remove('hidden'); }
function logout(){ TK=''; localStorage.removeItem('ab_admin_tk'); document.getElementById('dash').classList.add('hidden'); document.getElementById('login').classList.remove('hidden'); }

async function loadAll(){ try{ await Promise.all([loadStats(),loadPending(),loadUsers(),loadLogs(),loadPrompts()]); }catch(e){} }

async function loadStats(){
  var s=await (await api('/admin/stats')).json();
  var K=[['회원수',s.members],['활성 구독',s.active_subs],['AUTO 구독',s.auto_subs],['대기 결제',s.pending_payments],['판단 로그',s.decision_logs],['프롬프트 v',s.prompt_version]];
  document.getElementById('kpis').innerHTML=K.map(function(k){return '<div class="kpi"><div class="l">'+k[0]+'</div><div class="v">'+(k[1]==null?'-':k[1])+'</div></div>'}).join('');
  var on=s.maintenance; document.getElementById('mnt').innerHTML='<span class="tag '+(on?'b-off':'b-on')+'">'+(on?'점검중 ON':'정상 OFF')+'</span>';
}
async function toggleMnt(){
  var cur=document.getElementById('mnt').textContent.indexOf('ON')>=0 && document.getElementById('mnt').textContent.indexOf('점검')>=0;
  await api('/admin/maintenance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({on:!cur})});
  loadStats();
}
async function runFable(){
  if(!confirm('Fable 자가진화를 지금 실행할까요? (Claude Fable API 호출 · 표본이 적으면 건너뜀)')) return;
  var r=await (await api('/admin/evolve',{method:'POST'})).json();
  alert(r.ok? ('완료: '+r.summary+' (표본 '+r.samples+'개)') : ('건너뜀: '+r.reason));
  loadStats(); loadPrompts();
}
async function subUser(){
  var u=document.getElementById('su').value.trim(), t=document.getElementById('st').value, d=document.getElementById('sd').value;
  var m=document.getElementById('smsg'); m.textContent='';
  if(!u){ m.textContent='아이디를 입력하세요'; return; }
  var r=await api('/admin/subscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,tier:t,days:Number(d)})});
  if(r.ok){ var j=await r.json(); m.style.color='#4ade80'; m.textContent='✓ '+u+' → '+j.tier+' ('+String(j.expiry).slice(0,10)+'까지)'; loadStats(); loadUsers(); }
  else { m.style.color='#f87171'; m.textContent='실패: 그 아이디가 없습니다'; }
}
async function loadPending(){
  var j=await (await api('/admin/payments/pending')).json();
  var b=document.querySelector('#pend tbody');
  if(!j.pending.length){ b.innerHTML='<tr><td colspan="6" class="mut">대기중 결제신청 없음</td></tr>'; return; }
  b.innerHTML=j.pending.map(function(p){return '<tr><td>'+p.id+'</td><td>'+esc(p.username)+'</td><td>'+esc(p.tier)+'</td><td>'+(p.amount||0).toLocaleString()+'원</td><td class="mut">'+String(p.requested_at||'').slice(0,16)+'</td><td><button class="g" onclick="approve('+p.id+')">승인(30일)</button></td></tr>'}).join('');
}
async function approve(id){
  var r=await (await api('/admin/payments/approve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:id,days:30})})).json();
  alert('승인됨: '+r.tier+' ('+String(r.expiry).slice(0,10)+'까지)'); loadPending(); loadStats(); loadUsers();
}
async function loadUsers(){
  var q=document.getElementById('q').value.trim();
  var j=await (await api('/admin/users?q='+encodeURIComponent(q))).json();
  var b=document.querySelector('#users tbody');
  b.innerHTML=j.users.map(function(u){
    var st = u.banned?'<span class="tag b-off">강제해지</span>':(u.locked?'<span class="tag b-off">잠김</span>':'<span class="tag b-on">정상</span>');
    var sub = u.is_subscribed?'<span class="tag b-buy">'+esc(u.tier||'')+'</span>':'<span class="tag b-hold">미구독</span>';
    return '<tr><td>'+u.id+'</td><td>'+esc(u.username)+(u.role==='admin'?' 👑':'')+'</td><td>'+esc(u.real_name||'')+'</td><td>'+esc(u.tier||'-')+'</td><td>'+sub+'</td><td class="mut">'+String(u.subscription_expiry||'').slice(0,10)+'</td><td>'+st+'</td></tr>';
  }).join('') || '<tr><td colspan="7" class="mut">회원 없음</td></tr>';
}
async function loadLogs(){
  var j=await (await api('/admin/logs?limit=80')).json();
  var b=document.querySelector('#logs tbody');
  b.innerHTML=j.logs.map(function(l){
    var cls=l.decision==='BUY'?'b-buy':(l.decision==='SELL'?'b-sell':'b-hold');
    return '<tr><td class="mut">'+String(l.ts||'').slice(5,19)+'</td><td>'+esc(l.ticker)+'</td><td><span class="tag '+cls+'">'+esc(l.decision)+'</span></td><td class="mut">'+esc(l.reason||'')+'</td><td>'+(l.next_check_in||'-')+'s</td><td class="mut">'+(l.deepseek_ms||'-')+'/'+(l.sonnet_ms||'-')+'</td></tr>';
  }).join('') || '<tr><td colspan="6" class="mut">아직 판단 로그 없음</td></tr>';
}
async function loadPrompts(){
  var j=await (await api('/admin/prompts')).json();
  var b=document.querySelector('#prompts tbody');
  b.innerHTML=j.versions.map(function(v){
    return '<tr><td><b>v'+v.version+'</b></td><td>'+esc(v.author)+'</td><td>'+esc(v.summary||'')+'</td><td>'+(v.sample_count||0)+'</td><td>'+(v.active?'<span class="tag b-on">활성</span>':'')+'</td><td class="mut">'+String(v.created_at||'').slice(0,16)+'</td></tr>';
  }).join('');
}
// 자동 새로고침(통계·로그) 15초
setInterval(function(){ if(!document.getElementById('dash').classList.contains('hidden')){ loadStats(); loadLogs(); } }, 15000);
// 저장된 토큰이 있으면 바로 진입 시도
if(TK){ api('/admin/stats').then(function(){ show(); loadAll(); }).catch(function(){ logout(); }); }
</script>
</body></html>"""
