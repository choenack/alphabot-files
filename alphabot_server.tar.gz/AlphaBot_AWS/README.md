# AlphaBot AWS 서버 (FastAPI)

사용자 업비트 키를 **다루지 않는** 공개데이터 + AI 분석 + 회원/구독 전담 서버.
주문·잔고는 클라이언트(사용자 PC)만 한다.

## 구성 파일
- `settings.py` — 모든 비밀키/설정을 **환경변수(.env)** 에서 읽음
- `market_data.py` — 업비트 공개데이터 수집(커넥션풀·재시도·레이트리밋·배치·캐시 + RSI/MACD/볼린저)
- `db.py` — SQLite 스키마(회원·구독·AI판단로그·프롬프트진화·설정) + 헬퍼
- `auth.py` — 비밀번호 해싱(bcrypt/PBKDF2) + JWT(자체구현) + 인증 의존성 + 관리자 생성 CLI
- `ai_pipeline.py` — **DeepSeek(1차 요약) → Claude Sonnet(최종결정)** 2단계 파이프라인(공유캐시·실패안전)
- `fable.py` — 사후 정답지 백필 + **일요일 Claude Fable 자가진화** + 로그정리(백그라운드 스케줄러)
- `main.py` — FastAPI 라우팅(공개데이터·인증·신호·결제·관리자) + 시작 시 DB초기화/스케줄러 기동

## 엔드포인트
| 구분 | 메서드/경로 | 설명 |
|---|---|---|
| 데이터 | `GET /health` | 가동·키설정·점검상태 |
| 데이터 | `GET /v1/prices?coins=` | 현재가 배치 |
| 데이터 | `GET /v1/marketdata?coins=` | 다봉지표·호가·BTC맥락·공포탐욕 종합 |
| 인증 | `POST /auth/register` | 회원가입 |
| 인증 | `POST /auth/login` | 로그인 → JWT 발급(클라 호환) |
| 인증 | `GET /subscription` | 구독 상태 |
| 신호 | `GET /signals?coins=` | 구독 게이팅 + 3단계 AI 결정(클라 호환 스키마) |
| 결제 | `POST /payments/request` | 구독 신청(수동승인) |
| 관리자 | `GET /admin/stats·logs·prompts·payments/pending` | 대시보드 데이터 |
| 관리자 | `POST /admin/maintenance·payments/approve·evolve` | 점검스위치·구독승인·수동진화 |

## 배포
- **초간단 따라하기**: `AWS_배포_초간단가이드.md`
- **클라이언트 연결**: `client_integration_guide.md` (서버 주소 한 줄만 변경)

## 로컬 빠른 확인
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python auth.py create-admin admin 비밀번호     # 관리자 1명 생성
uvicorn main:app --reload
# http://127.0.0.1:8000/health
```

## 다음에 이어붙일 것(선택)
폰 조회용 웹 대시보드(`/status/push`,`/m`), 사용자↔관리자 메시지, 결제 QR 페이지, 관리자 **웹 UI(HTML)**.
지금 상태로도 로그인 → 신호 수신 → 자동매매 + 관리자 JSON API + 일요일 자가진화는 완전히 동작.
