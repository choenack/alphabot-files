# 🚀 AWS 서버 올리기 — 아주 쉽게 (따라만 하세요)

목표: 방금 만든 서버 파일들을 AWS(Lightsail) 컴퓨터에 올려서 24시간 켜두기.
준비물: AWS Lightsail 인스턴스(Ubuntu) 1개, 그 서버의 IP 주소, 방금 받은 Claude 키·DeepSeek 키.

> 💡 컴퓨터에 명령어를 그대로 복사-붙여넣기 하면 됩니다. `<...>` 부분만 여러분 값으로 바꾸세요.

---

## 1단계. 서버 컴퓨터에 접속하기
내 PC에서 터미널(윈도우는 PowerShell)을 열고:
```bash
ssh ubuntu@<AWS_서버_IP>
```
처음이면 "yes" 입력. 이제 화면이 AWS 컴퓨터 안으로 들어갑니다.

## 2단계. 필요한 프로그램 설치
```bash
sudo apt update
sudo apt install -y python3-venv python3-pip
```

## 3단계. 서버 파일 올리기
**방법 A (내 PC에서 통째로 복사 — 새 터미널 창에서, 내 PC 기준):**
```bash
scp -r AlphaBot_AWS ubuntu@<AWS_서버_IP>:~/alphabot-server
```
그다음 다시 AWS 접속 화면으로 돌아가서:
```bash
cd ~/alphabot-server
```

## 4단계. 파이썬 준비 + 부품 설치
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```
(1~2분 걸립니다. 커피 한 잔 ☕)

## 5단계. 비밀키 넣기 (제일 중요)
```bash
cp .env.example .env
nano .env
```
편집기가 열리면 두 줄을 여러분 키로 채웁니다:
```
ANTHROPIC_API_KEY=sk-ant-...(Claude 키)
DEEPSEEK_API_KEY=...(DeepSeek 키)
```
저장: `Ctrl+O` → `Enter` → `Ctrl+X`. 그다음 파일 잠그기:
```bash
chmod 600 .env
```

## 6단계. 관리자 계정 만들기
```bash
set -a; source .env; set +a
python auth.py create-admin <원하는아이디> <원하는비밀번호>
```
"[OK] 관리자 생성됨" 이 뜨면 성공.

## 7단계. 켜보기 (테스트)
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```
이제 웹브라우저에서 열어봅니다:
- `http://<AWS_서버_IP>:8000/health` → `{"ok": true ...}` 나오면 서버 살아있음 ✅
- `http://<AWS_서버_IP>:8000/v1/marketdata?coins=KRW-BTC,KRW-ETH` → 업비트 데이터가 쭉 나오면 수집기 정상 ✅

> ⚠️ 안 열리면: AWS Lightsail 웹사이트 → 인스턴스 → **네트워킹 → 방화벽**에서 **포트 8000**(또는 443)을 "추가"하세요.

확인했으면 터미널에서 `Ctrl+C`로 잠깐 끕니다(다음 단계에서 24시간 모드로 켤 거예요).

## 8단계. 24시간 자동으로 켜두기 (systemd)
아래 파일을 만듭니다:
```bash
sudo nano /etc/systemd/system/alphabot.service
```
붙여넣기 (사용자명이 ubuntu가 아니면 경로만 바꾸세요):
```ini
[Unit]
Description=AlphaBot AWS Server
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/alphabot-server
EnvironmentFile=/home/ubuntu/alphabot-server/.env
ExecStart=/home/ubuntu/alphabot-server/.venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```
저장(`Ctrl+O`,`Enter`,`Ctrl+X`) 후:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now alphabot
sudo systemctl status alphabot     # 초록불(active running) 확인
```
이제 서버가 껐다 켜져도, 오류로 멈춰도 **자동으로 다시 켜집니다.** 로그 보고 싶으면:
```bash
journalctl -u alphabot -f
```

## 9단계. 클라이언트(고객 프로그램) 연결
`AlphaBot_Client/config.py`에서 서버 주소 한 줄만 바꾸고 다시 빌드하면 끝:
```python
SERVER_BASE_URL = "http://<AWS_서버_IP>:8000"
```
(자세한 건 `client_integration_guide.md` 참고)

---

## 자주 쓰는 명령어 (외워두면 편함)
```bash
sudo systemctl restart alphabot     # 코드 바꾼 뒤 재시작
sudo systemctl stop alphabot        # 잠깐 끄기
journalctl -u alphabot -n 100       # 최근 로그 100줄
```

## 관리(회원/구독/점검/진화이력)는 어떻게?
지금은 관리자용 **JSON API**가 준비돼 있습니다(로그인해서 토큰 받고 호출). 예:
- `GET /admin/stats` — 회원수·구독수·프롬프트 버전
- `GET /admin/logs` — AI 판단 로그(가동 모니터링)
- `GET /admin/prompts` — Fable 진화 이력
- `POST /admin/maintenance {"on": true}` — 서버 점검 스위치
- `POST /admin/payments/approve {"request_id": 1, "days": 30}` — 구독 승인
- `POST /admin/evolve` — Fable 자가진화 지금 1회 실행

> 브라우저에서 클릭으로 쓰는 **관리자 웹 화면(HTML)**은 다음 단계에서 붙이면 더 편해집니다.
