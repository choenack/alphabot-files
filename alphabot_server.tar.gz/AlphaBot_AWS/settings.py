# -*- coding: utf-8 -*-
"""
settings.py — 서버 설정(전부 '환경변수'에서 읽는다).
=====================================================
비밀키(ANTHROPIC/DEEPSEEK)는 코드에 절대 안 박고, 서버의 .env(또는 systemd EnvironmentFile)
에서만 읽는다. 이 파일에는 '기본값/비밀 아닌 것'만 둔다.
"""
import os


def _env(key: str, default: str = "") -> str:
    return (os.environ.get(key, default) or "").strip()


class Settings:
    # ── 비밀키(반드시 환경변수로만) ──────────────────────────
    ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")   # 서버 .env 에만 존재. 절대 코드/깃/클라이언트에 두지 않음
    DEEPSEEK_API_KEY = _env("DEEPSEEK_API_KEY")

    # ── AI 엔드포인트/모델 ───────────────────────────────────
    # DeepSeek(1차 요약)은 OpenAI 호환. Claude(최종결정/자가진화)는 네이티브 Messages API.
    DEEPSEEK_BASE_URL = _env("DEEPSEEK_BASE_URL", "https://api.deepseek.com/chat/completions")
    DEEPSEEK_MODEL = _env("DEEPSEEK_MODEL", "deepseek-v4-pro")
    ANTHROPIC_BASE_URL = _env("ANTHROPIC_BASE_URL", "https://api.anthropic.com/v1/messages")
    ANTHROPIC_VERSION = _env("ANTHROPIC_VERSION", "2023-06-01")
    # [비용 레버 3] 평상시(대부분 HOLD) 판단은 값싼 Haiku로, 실제 매매(BUY/SELL)만 Sonnet으로 재확인.
    DECISION_MODEL = _env("DECISION_MODEL", "claude-haiku-4-5-20251001")   # 1차 판단(싸다: $1/$5)
    SONNET_MODEL = _env("SONNET_MODEL", "claude-sonnet-5")   # BUY/SELL 재확인(정확: $3/$15)
    ESCALATE_ACTIONABLE = _env("ESCALATE_ACTIONABLE", "1") == "1"          # BUY/SELL만 Sonnet 재확인
    FABLE_MODEL = _env("FABLE_MODEL", "claude-fable-5")      # 일요일 프롬프트 자가진화

    # ── 업비트 공개 API ──────────────────────────────────────
    UPBIT_BASE = _env("UPBIT_BASE", "https://api.upbit.com/v1")
    UPBIT_MAX_REQ_PER_SEC = int(_env("UPBIT_MAX_REQ_PER_SEC", "8"))   # 공개 API ~10/s → 여유 8

    # ── 인증(JWT) ────────────────────────────────────────────
    JWT_SECRET = _env("JWT_SECRET")                        # 비면 DB에 자동 생성·보관(get_jwt_secret)
    JWT_EXP_DAYS = int(_env("JWT_EXP_DAYS", "30"))         # 토큰 유효기간(일)

    # ── 서버 ─────────────────────────────────────────────────
    PORT = int(_env("PORT", "8000"))
    DB_PATH = _env("DB_PATH", "alphabot.db")
    SIGNAL_TTL_SEC = int(_env("SIGNAL_TTL_SEC", "900"))     # 신호 신선도 상한(기본 15분)
    # [비용 레버 1] next_check_in 하한 — AI가 "60초 뒤 봐"라고 해도 최소 이만큼은 기다린다.
    # 300초로 올리면 급변장에서 재판단(=AI 호출) 폭주를 막아 비용을 크게 낮춘다.
    SIGNAL_MIN_TTL_SEC = int(_env("SIGNAL_MIN_TTL_SEC", "300"))
    SIGNAL_FAIL_RETRY_SEC = int(_env("SIGNAL_FAIL_RETRY_SEC", "60"))  # AI 실패 시 짧은 재시도
    # [비용 레버 4] 한 번에 분석하는 코인 수 상한(많을수록 배치가 커져 비용↑).
    SIGNAL_MAX_COINS = int(_env("SIGNAL_MAX_COINS", "20"))
    OHLCV_CACHE_SEC = int(_env("OHLCV_CACHE_SEC", "20"))    # 캔들/지표 캐시(초) — 과호출 방지
    AI_TIMEOUT_SEC = int(_env("AI_TIMEOUT_SEC", "90"))     # DeepSeek/Claude 호출 타임아웃

    # ── 구독 등급/가격(원) — 클라이언트/결제와 동일하게 ──────
    TIERS = {"AUTO": 30000, "DATA_ONLY": 10000}

    def masked(self) -> dict:
        """상태 점검용 — 키의 존재 여부만(값은 절대 노출 안 함)."""
        return {
            "anthropic_key_set": bool(self.ANTHROPIC_API_KEY),
            "deepseek_key_set": bool(self.DEEPSEEK_API_KEY),
            "sonnet_model": self.SONNET_MODEL,
            "fable_model": self.FABLE_MODEL,
            "deepseek_model": self.DEEPSEEK_MODEL,
        }


settings = Settings()
