# -*- coding: utf-8 -*-
"""
main.py — AlphaBot AWS 서버 (FastAPI) · 전체 통합
=====================================================
[역할 분리] 이 서버는 '공개데이터 + AI 분석 + 회원/구독'만. 사용자 업비트 키/주문은 클라이언트(PC)만.
[클라이언트 호환] /auth/login·/subscription·/signals 의 JSON/에러 형식을 기존 클라이언트가 파싱하던
                 규격에 '그대로' 맞춘다 → 클라이언트는 서버 주소만 바꾸면 됨(최소 수정).

엔드포인트
  공개데이터(디버그/검증): GET /health /v1/markets /v1/prices /v1/marketdata
  인증:               POST /auth/register  POST /auth/login  GET /subscription
  신호(구독 게이팅):    GET /signals?coins=KRW-BTC,KRW-ETH
  결제신청:            POST /payments/request
  관리자(웹 대시보드):  GET /admin/stats /admin/logs /admin/prompts /admin/payments/pending
                      POST /admin/maintenance /admin/payments/approve /admin/evolve
실행: uvicorn main:app --host 0.0.0.0 --port 8000
"""
import re
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Query, Header, Request, Depends, HTTPException
from fastapi.responses import JSONResponse

import db
import auth
import market_data
import ai_pipeline
import fable
from settings import settings

_TICKER_RE = re.compile(r"^KRW-[A-Z0-9]{2,10}$")
_MAX_COINS = 30


def _parse_coins(coins: str) -> list:
    raw = [c.strip().upper() for c in (coins or "").split(",") if c.strip()]
    valid = [c for c in dict.fromkeys(raw) if _TICKER_RE.match(c)]
    return valid[:_MAX_COINS]


def _sub_payload(u: dict) -> dict:
    return {"active": db.is_active(u), "tier": u.get("tier"),
            "expiry": u.get("subscription_expiry"), "username": u.get("username"),
            "banned": bool(u.get("banned"))}


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()              # 테이블 생성 + 시드
    fable.start_scheduler()   # 사후정답지 백필 + 일요일 자가진화 + 로그정리(백그라운드)
    yield


app = FastAPI(title="AlphaBot AWS Server", version="1.0.0", lifespan=lifespan)


# ── 공개데이터(검증/디버그) ──────────────────────────────────────────
@app.get("/health")
def health():
    return {"ok": True, "ts": int(time.time()), "config": settings.masked(),
            "maintenance": db.maintenance_on()}


@app.get("/v1/markets")
def markets():
    return {"markets": market_data.get_markets_krw()}


@app.get("/v1/prices")
def prices(coins: str = Query(...)):
    ms = _parse_coins(coins)
    if not ms:
        raise HTTPException(400, "유효한 KRW 티커 없음")
    return {"prices": market_data.get_prices(ms)}


@app.get("/v1/marketdata")
def marketdata(coins: str = Query(...)):
    ms = _parse_coins(coins)
    if not ms:
        raise HTTPException(400, "유효한 KRW 티커 없음")
    t0 = time.time()
    data = market_data.collect(ms)
    data["elapsed_ms"] = int((time.time() - t0) * 1000)
    return data


# ── 인증(클라이언트 호환 형식) ───────────────────────────────────────
@app.post("/auth/register")
async def register(request: Request):
    d = await request.json()
    uid = (d.get("username") or "").strip()
    pw = d.get("password") or ""
    nm = (d.get("real_name") or "").strip()
    if len(uid) < 3 or len(pw) < 6 or not nm:
        return JSONResponse({"error": "invalid"}, status_code=400)
    try:
        db.create_user(uid, auth.hash_password(pw), nm, "user")
    except ValueError:
        return JSONResponse({"error": "duplicate"}, status_code=409)
    return JSONResponse({"ok": True}, status_code=201)


@app.post("/auth/login")
async def login(request: Request):
    d = await request.json()
    uid = (d.get("username") or "").strip()
    pw = d.get("password") or ""
    user = db.get_user_by_name(uid)
    if not user or not auth.verify_password(pw, user["password_hash"]):
        return JSONResponse({"error": "bad_pw"}, status_code=401)
    if user.get("locked"):
        return JSONResponse({"error": "locked"}, status_code=403)
    # 최근 접속 기록(비필수)
    try:
        db.set_config(f"_lastseen_{user['id']}", str(int(time.time())))
    except Exception:
        pass
    token = auth.make_token(user)
    return {"token": token, "username": user["username"], "role": user.get("role", "user"),
            "subscription": _sub_payload(user)}


@app.get("/subscription")
def subscription(user: dict = Depends(auth.current_user)):
    return _sub_payload(user)


# ── 신호(구독 게이팅 · 클라이언트 호환 에러코드) ─────────────────────
@app.get("/signals")
def signals(coins: str = Query(""),
            authorization: str | None = Header(default=None),
            x_bot_mode: str | None = Header(default=None),
            x_hwid: str | None = Header(default=None)):
    # 점검 모드면 '서버 일시중지'로(클라는 ServerError로 처리 → 로컬 손절감시는 계속)
    if db.maintenance_on():
        return JSONResponse({"error": "maintenance", "signals": []}, status_code=503)
    payload = auth.decode_token(authorization[7:].strip()) if (authorization or "").startswith("Bearer ") else None
    if not payload:
        return JSONResponse({"error": "unauth"}, status_code=401)
    user = db.get_user(int(payload.get("sub", 0)))
    if not user:
        return JSONResponse({"error": "unauth"}, status_code=401)
    if user.get("locked"):
        return JSONResponse({"error": "locked"}, status_code=403)
    if user.get("banned"):
        return JSONResponse({"error": "banned"}, status_code=403)
    if not db.is_active(user):
        return JSONResponse({"error": "no_subscription"}, status_code=403)
    ms = _parse_coins(coins)
    if not ms:
        return {"signals": []}
    try:
        sigs = ai_pipeline.get_signals(ms)
    except Exception as e:
        return JSONResponse({"error": f"ai_failed: {e}", "signals": []}, status_code=200)
    return {"signals": sigs}


# ── 결제 신청(수동 승인) ─────────────────────────────────────────────
@app.post("/payments/request")
async def payment_request(request: Request, user: dict = Depends(auth.current_user)):
    if user.get("banned"):
        return JSONResponse({"error": "banned"}, status_code=403)
    d = await request.json()
    tier = d.get("tier") if d.get("tier") in settings.TIERS else "DATA_ONLY"
    amount = settings.TIERS[tier]
    rid = db.create_payment_request(user["id"], user["username"], amount, tier, f"{tier} 구독 신청")
    return {"request_id": rid, "amount": amount, "tier": tier, "status": "pending"}


# ── 관리자(웹 대시보드) ──────────────────────────────────────────────
@app.get("/admin/stats")
def admin_stats(admin: dict = Depends(auth.admin_required)):
    return db.admin_stats()


@app.get("/admin/logs")
def admin_logs(limit: int = 100, admin: dict = Depends(auth.admin_required)):
    return {"logs": db.recent_log(min(max(limit, 1), 500))}


@app.get("/admin/prompts")
def admin_prompts(admin: dict = Depends(auth.admin_required)):
    return {"versions": db.list_prompt_versions(),
            "last_evolution": db.get_config("fable_last_result", "")}


@app.get("/admin/payments/pending")
def admin_pending(admin: dict = Depends(auth.admin_required)):
    return {"pending": db.pending_payments()}


@app.post("/admin/maintenance")
async def admin_maintenance(request: Request, admin: dict = Depends(auth.admin_required)):
    d = await request.json()
    db.set_config("maintenance_mode", "1" if d.get("on") else "0")
    return {"maintenance": db.maintenance_on()}


@app.post("/admin/payments/approve")
async def admin_approve(request: Request, admin: dict = Depends(auth.admin_required)):
    d = await request.json()
    rid = int(d.get("request_id", 0))
    days = int(d.get("days", 30))
    pend = {p["id"]: p for p in db.pending_payments()}
    p = pend.get(rid)
    if not p:
        raise HTTPException(404, "대기중 결제신청 아님")
    exp = db.grant_subscription(p["user_id"], p["tier"], days, note=f"결제#{rid} 승인")
    # 신청 상태 갱신
    c = db._con()
    with db._write_lock:
        c.execute("UPDATE payment_requests SET status='approved', approved_at=? WHERE id=?",
                  (time.strftime("%Y-%m-%dT%H:%M:%S"), rid))
        c.commit()
    c.close()
    return {"ok": True, "expiry": exp, "tier": p["tier"]}


@app.post("/admin/evolve")
def admin_evolve(admin: dict = Depends(auth.admin_required)):
    """수동으로 Fable 자가진화 1회 실행(테스트/즉시적용용)."""
    return fable.run_weekly_evolution(force=True)
