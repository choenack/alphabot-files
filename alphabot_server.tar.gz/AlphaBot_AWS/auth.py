# -*- coding: utf-8 -*-
"""
auth.py — 인증(비밀번호 해싱 + JWT 발급/검증) + FastAPI 인증 의존성
=====================================================
· 비밀번호: bcrypt로 해싱(설치돼 있으면). 없으면 표준 라이브러리 PBKDF2로 폴백 → 어디서든 동작.
            저장값 앞에 방식 태그가 있어 검증 시 자동 판별(bcrypt/pbkdf2 혼재 안전).
· JWT: 외부 라이브러리 없이 표준 라이브러리(hmac/hashlib/base64)로 HS256 직접 구현.
       비밀서명키(JWT_SECRET)는 환경변수 우선, 없으면 DB에 한 번 생성해 보관(재시작해도 토큰 유지).
· 클라이언트 호환: 로그인 응답의 'token'을 그대로 Authorization: Bearer 로 보내면 됨(기존 그대로).
"""
import os
import json
import time
import hmac
import base64
import hashlib
import secrets as _secrets

from fastapi import Header, HTTPException

import db
from settings import settings

# bcrypt는 있으면 쓰고 없으면 PBKDF2로 자동 폴백
try:
    import bcrypt as _bcrypt
except Exception:
    _bcrypt = None


# ── 비밀번호 해싱 ────────────────────────────────────────────────────
def hash_password(pw: str) -> str:
    pw = pw or ""
    if _bcrypt is not None:
        return "bcrypt$" + _bcrypt.hashpw(pw.encode(), _bcrypt.gensalt()).decode()
    # 폴백: PBKDF2-HMAC-SHA256 (표준 라이브러리)
    salt = _secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000)
    return "pbkdf2$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(pw: str, stored: str) -> bool:
    pw = pw or ""
    stored = stored or ""
    try:
        if stored.startswith("bcrypt$"):
            if _bcrypt is None:
                return False
            return _bcrypt.checkpw(pw.encode(), stored[len("bcrypt$"):].encode())
        if stored.startswith("pbkdf2$"):
            _, b64salt, b64dk = stored.split("$", 2)
            salt = base64.b64decode(b64salt)
            expect = base64.b64decode(b64dk)
            dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000)
            return hmac.compare_digest(dk, expect)
        # 태그 없는 옛 bcrypt 원본도 시도
        if _bcrypt is not None and stored.startswith("$2"):
            return _bcrypt.checkpw(pw.encode(), stored.encode())
    except Exception:
        return False
    return False


# ── JWT (HS256, 표준 라이브러리 자체 구현) ───────────────────────────
def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def get_jwt_secret() -> str:
    """서명키: 환경변수 JWT_SECRET 우선, 없으면 DB에 한 번 생성해 보관(재시작해도 동일)."""
    if settings.JWT_SECRET:
        return settings.JWT_SECRET
    sec = db.get_config("jwt_secret", "")
    if not sec:
        sec = _secrets.token_hex(32)
        db.set_config("jwt_secret", sec)
    return sec


def make_token(user: dict) -> str:
    now = int(time.time())
    payload = {
        "sub": user["id"], "username": user["username"], "role": user.get("role", "user"),
        "iat": now, "exp": now + settings.JWT_EXP_DAYS * 86400,
    }
    header = {"alg": "HS256", "typ": "JWT"}
    seg = _b64u(json.dumps(header, separators=(",", ":")).encode()) + "." + \
          _b64u(json.dumps(payload, separators=(",", ":")).encode())
    sig = _b64u(hmac.new(get_jwt_secret().encode(), seg.encode(), hashlib.sha256).digest())
    return seg + "." + sig


def decode_token(token: str) -> dict | None:
    try:
        seg1, seg2, sig = token.split(".")
        expect = _b64u(hmac.new(get_jwt_secret().encode(), f"{seg1}.{seg2}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expect):
            return None
        payload = json.loads(_b64u_dec(seg2))
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload
    except Exception:
        return None


# ── FastAPI 인증 의존성 ──────────────────────────────────────────────
def _token_from_header(authorization: str | None) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="unauth")
    return authorization[7:].strip()


def current_user(authorization: str | None = Header(default=None)) -> dict:
    """유효한 JWT → 사용자 dict. 아니면 401. locked/banned도 여기서 차단."""
    payload = decode_token(_token_from_header(authorization))
    if not payload:
        raise HTTPException(status_code=401, detail="invalid_token")
    user = db.get_user(int(payload.get("sub", 0)))
    if not user:
        raise HTTPException(status_code=401, detail="no_user")
    if user.get("locked"):
        raise HTTPException(status_code=403, detail="locked")
    if user.get("banned"):
        raise HTTPException(status_code=403, detail="banned")
    return user


def admin_required(authorization: str | None = Header(default=None)) -> dict:
    user = current_user(authorization)
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="admin_only")
    return user


# ── CLI: 관리자 계정 만들기 / 해시 출력 ──────────────────────────────
#   python auth.py create-admin <아이디> <비밀번호>   → DB에 관리자 계정 생성
#   python auth.py hash <비밀번호>                     → 비번 해시만 출력(ADMIN_PASSWORD_HASH용)
if __name__ == "__main__":
    import sys
    db.init_db()
    if len(sys.argv) >= 4 and sys.argv[1] == "create-admin":
        uname, pw = sys.argv[2], sys.argv[3]
        try:
            uid = db.create_user(uname, hash_password(pw), "관리자", "admin")
            print(f"[OK] 관리자 생성됨: {uname} (id={uid})")
        except ValueError as e:
            print(f"[실패] {e}")
    elif len(sys.argv) >= 3 and sys.argv[1] == "hash":
        print(hash_password(sys.argv[2]))
    else:
        print("사용법:\n  python auth.py create-admin <아이디> <비밀번호>\n  python auth.py hash <비밀번호>")
